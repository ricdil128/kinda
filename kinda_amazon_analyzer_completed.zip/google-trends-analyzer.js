// google-trends-analyzer.js - Integra i dati di Google Trends per l'analisi delle keyword

// Configurazione per l'analisi di Google Trends
const TRENDS_CONFIG = {
  // Periodi di tempo per l'analisi
  timePeriods: {
    shortTerm: 'now 7-d',    // Ultimi 7 giorni
    mediumTerm: 'today 3-m', // Ultimi 3 mesi
    longTerm: 'today 12-m'   // Ultimi 12 mesi
  },
  
  // Regioni geografiche supportate
  regions: {
    'US': 'US',
    'UK': 'GB',
    'IT': 'IT',
    'DE': 'DE',
    'FR': 'FR',
    'ES': 'ES'
  },
  
  // Endpoint del proxy per aggirare le limitazioni CORS
  proxyEndpoint: 'https://kinda-trends-proxy.herokuapp.com/api/trends',
  
  // Intervallo di aggiornamento della cache in millisecondi (1 giorno)
  cacheExpiration: 86400000
};

// Classe per l'analisi di Google Trends
class GoogleTrendsAnalyzer {
  constructor(config = TRENDS_CONFIG) {
    this.config = config;
    this.cache = {};
  }
  
  // Analizza una keyword su Google Trends
  async analyzeKeyword(keyword, region = 'US') {
    if (!keyword) {
      console.error('Keyword non valida per l\'analisi di Google Trends');
      return null;
    }
    
    try {
      // Verifica se i dati sono già in cache
      const cacheKey = `${keyword}_${region}`;
      const cachedData = this.getCachedData(cacheKey);
      
      if (cachedData) {
        console.log(`Utilizzando dati in cache per ${keyword} (${region})`);
        return cachedData;
      }
      
      // Prepara i risultati
      const results = {
        keyword,
        region,
        timestamp: Date.now(),
        shortTerm: await this.fetchTrendsData(keyword, this.config.timePeriods.shortTerm, region),
        mediumTerm: await this.fetchTrendsData(keyword, this.config.timePeriods.mediumTerm, region),
        longTerm: await this.fetchTrendsData(keyword, this.config.timePeriods.longTerm, region)
      };
      
      // Calcola i trend
      results.shortTermTrend = this.calculateTrend(results.shortTerm);
      results.mediumTermTrend = this.calculateTrend(results.mediumTerm);
      results.longTermTrend = this.calculateTrend(results.longTerm);
      
      // Calcola il punteggio complessivo
      results.overallScore = this.calculateOverallScore(results);
      
      // Salva nella cache
      this.cacheData(cacheKey, results);
      
      return results;
    } catch (error) {
      console.error(`Errore nell'analisi di Google Trends per ${keyword}:`, error);
      return {
        keyword,
        region,
        error: error.message
      };
    }
  }
  
  // Recupera i dati di Google Trends
  async fetchTrendsData(keyword, timePeriod, region) {
    try {
      // In un'implementazione reale, questa funzione farebbe una richiesta a un proxy server
      // che a sua volta utilizzerebbe l'API non ufficiale di Google Trends
      // Per questa demo, simuliamo i dati
      
      // Simula una richiesta al proxy
      console.log(`Recupero dati di Google Trends per "${keyword}" (${region}, ${timePeriod})`);
      
      // Simula un ritardo di rete
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Genera dati simulati
      return this.generateMockTrendsData(keyword, timePeriod);
    } catch (error) {
      console.error('Errore nel recupero dei dati di Google Trends:', error);
      throw error;
    }
  }
  
  // Genera dati simulati per Google Trends
  generateMockTrendsData(keyword, timePeriod) {
    // Determina il numero di punti dati in base al periodo
    let numPoints;
    if (timePeriod === this.config.timePeriods.shortTerm) {
      numPoints = 7;  // 7 giorni
    } else if (timePeriod === this.config.timePeriods.mediumTerm) {
      numPoints = 12; // 12 settimane
    } else {
      numPoints = 12; // 12 mesi
    }
    
    // Genera punti dati casuali con una tendenza basata sulla lunghezza della keyword
    // (solo per simulazione - in realtà useremmo dati reali)
    const baseValue = 50 + (keyword.length % 30);
    const trend = (keyword.length % 10) - 5; // Trend tra -5 e +4
    
    const timePoints = [];
    const values = [];
    
    for (let i = 0; i < numPoints; i++) {
      // Calcola il valore con un po' di casualità
      const randomFactor = Math.random() * 20 - 10; // Fattore casuale tra -10 e +10
      const value = Math.max(0, Math.min(100, baseValue + (trend * i / 2) + randomFactor));
      
      // Aggiungi il punto dati
      values.push(Math.round(value));
      
      // Aggiungi il punto temporale
      const date = new Date();
      if (timePeriod === this.config.timePeriods.shortTerm) {
        date.setDate(date.getDate() - (numPoints - i - 1));
      } else if (timePeriod === this.config.timePeriods.mediumTerm) {
        date.setDate(date.getDate() - (numPoints - i - 1) * 7);
      } else {
        date.setMonth(date.getMonth() - (numPoints - i - 1));
      }
      
      timePoints.push(date.toISOString().split('T')[0]);
    }
    
    return {
      timePoints,
      values
    };
  }
  
  // Calcola il trend dai dati
  calculateTrend(trendsData) {
    if (!trendsData || !trendsData.values || trendsData.values.length < 2) {
      return 0;
    }
    
    const values = trendsData.values;
    
    // Calcola la differenza percentuale tra l'ultimo e il primo valore
    const firstValue = values[0];
    const lastValue = values[values.length - 1];
    
    if (firstValue === 0) return 0;
    
    return ((lastValue - firstValue) / firstValue) * 100;
  }
  
  // Calcola il punteggio complessivo
  calculateOverallScore(results) {
    // Pesi per i diversi periodi
    const shortTermWeight = 0.5;
    const mediumTermWeight = 0.3;
    const longTermWeight = 0.2;
    
    // Normalizza i trend (da percentuale a valore tra 0 e 1)
    const normalizeValue = (value) => {
      // Limita i valori tra -100% e +100%
      const limitedValue = Math.max(-100, Math.min(100, value));
      // Converti da -100/+100 a 0/1
      return (limitedValue + 100) / 200;
    };
    
    const shortTermScore = normalizeValue(results.shortTermTrend);
    const mediumTermScore = normalizeValue(results.mediumTermTrend);
    const longTermScore = normalizeValue(results.longTermTrend);
    
    // Calcola il punteggio ponderato
    const weightedScore = (shortTermScore * shortTermWeight) +
                         (mediumTermScore * mediumTermWeight) +
                         (longTermScore * longTermWeight);
    
    // Converti in un punteggio da 0 a 10
    return weightedScore * 10;
  }
  
  // Recupera dati dalla cache
  getCachedData(cacheKey) {
    const cachedItem = this.cache[cacheKey];
    
    if (cachedItem && (Date.now() - cachedItem.timestamp < this.config.cacheExpiration)) {
      return cachedItem;
    }
    
    return null;
  }
  
  // Salva dati nella cache
  cacheData(cacheKey, data) {
    this.cache[cacheKey] = data;
  }
  
  // Pulisci la cache
  clearCache() {
    this.cache = {};
  }
}

// Esporta la classe
export default GoogleTrendsAnalyzer;
