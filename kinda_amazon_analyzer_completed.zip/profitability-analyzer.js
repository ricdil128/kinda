// profitability-analyzer.js - Gestisce l'analisi di profittabilità per i libri Amazon

// Configurazione per l'analisi di profittabilità
const PROFITABILITY_CONFIG = {
  // Costi di stampa per pagina in base al formato
  printingCosts: {
    paperback: {
      blackAndWhite: {
        baseCost: 0.85,  // Costo base fisso
        perPage: 0.012   // Costo per pagina in bianco e nero
      },
      color: {
        baseCost: 0.85,
        perPage: 0.036   // Costo per pagina a colori
      }
    },
    hardcover: {
      blackAndWhite: {
        baseCost: 1.95,
        perPage: 0.014
      },
      color: {
        baseCost: 1.95,
        perPage: 0.042
      }
    }
  },
  
  // Percentuali di royalty per formato
  royaltyPercentages: {
    paperback: 0.60,     // 60% per paperback
    hardcover: 0.60,     // 60% per hardcover
    kindle: 0.70         // 70% per Kindle
  },
  
  // Formule per stimare le vendite giornaliere in base al BSR
  salesEstimation: {
    // Formula per stimare le vendite giornaliere in base al BSR
    // Basata su dati empirici e ricerche di mercato
    calculateDailySales: function(bsr, category = 'books') {
      if (!bsr || bsr <= 0) return 0;
      
      // Formule diverse per categorie diverse
      switch (category.toLowerCase()) {
        case 'books':
          if (bsr < 100) return 350;
          if (bsr < 1000) return 110;
          if (bsr < 10000) return 32;
          if (bsr < 50000) return 5;
          if (bsr < 100000) return 2;
          return 1;
        
        case 'kindle':
          if (bsr < 100) return 450;
          if (bsr < 1000) return 150;
          if (bsr < 10000) return 40;
          if (bsr < 50000) return 7;
          if (bsr < 100000) return 3;
          return 1;
          
        default:
          // Formula generica
          return Math.max(1, Math.round(100000 / bsr));
      }
    }
  },
  
  // Parametri per l'analisi pubblicitaria
  advertisingAnalysis: {
    // Percentuale ottimale di ACOS rispetto al break-even
    optimalAcosRatio: 0.67,  // 67% del break-even ACOS
    
    // Click per vendita stimati in base alla categoria
    clicksPerSale: {
      fiction: 8,
      nonFiction: 12,
      technical: 15,
      children: 6,
      default: 10
    },
    
    // Peso pubblicitario massimo consigliato (percentuale del fatturato)
    maxAdWeight: 0.35  // 35% del fatturato
  }
};

// Classe per l'analisi di profittabilità
class ProfitabilityAnalyzer {
  constructor(config = PROFITABILITY_CONFIG) {
    this.config = config;
  }
  
  // Analizza la profittabilità di un libro
  analyzeBook(bookData) {
    if (!bookData || !bookData.asin) {
      console.error('Dati del libro non validi per l\'analisi di profittabilità');
      return {};
    }
    
    try {
      // Risultati dell'analisi
      const results = {
        asin: bookData.asin,
        timestamp: Date.now()
      };
      
      // Estrai e normalizza i dati di input
      const inputData = this.normalizeInputData(bookData);
      
      // Calcola i costi di stampa
      const printingCost = this.calculatePrintingCost(inputData);
      results.printingCost = printingCost;
      
      // Calcola le royalty
      const royalty = this.calculateRoyalty(inputData, printingCost);
      results.royalty = royalty;
      
      // Stima le vendite giornaliere
      const dailySales = this.estimateDailySales(inputData);
      results.copiesPerDay = dailySales;
      
      // Calcola l'ACOS di break-even
      const breakEvenAcos = this.calculateBreakEvenAcos(inputData, royalty);
      results.breakEvenAcos = breakEvenAcos;
      
      // Calcola l'ACOS ottimale
      const bestAcos = this.calculateOptimalAcos(breakEvenAcos);
      results.bestAcos = bestAcos;
      
      // Calcola la spesa pubblicitaria giornaliera
      const adSpend = this.calculateDailyAdSpend(inputData, bestAcos, dailySales);
      results.adSpend = adSpend;
      
      // Calcola l'incasso lordo giornaliero
      const dailyGross = this.calculateDailyGross(inputData, dailySales);
      results.dailyGross = dailyGross;
      
      // Calcola l'incasso lordo mensile
      const monthlyGross = dailyGross * 30;
      results.monthlyGross = monthlyGross;
      
      // Calcola il profitto netto mensile
      const netProfit = this.calculateMonthlyNetProfit(royalty, dailySales, adSpend);
      results.netProfit = netProfit;
      
      // Calcola la spesa pubblicitaria totale mensile
      const adSpendTotal = adSpend * 30;
      results.adSpendTotal = adSpendTotal;
      
      // Calcola il peso della pubblicità
      const adWeight = this.calculateAdWeight(adSpendTotal, monthlyGross);
      results.adWeight = adWeight;
      
      // Calcola il CPC (costo per click)
      const cpc = this.calculateCPC(adSpend, dailySales, inputData.category);
      results.cpc = cpc;
      
      // Calcola gli score
      results.scoreSimple = this.calculateSimpleScore(inputData, results);
      results.scoreSimple2 = this.calculateSimpleScore2(inputData, results);
      results.scoreSN = this.calculateSNScore(inputData, results);
      results.scoreSN2 = this.calculateSNScore2(inputData, results);
      
      // Arrotonda i valori numerici per una migliore leggibilità
      return this.roundNumericValues(results);
    } catch (error) {
      console.error('Errore nell\'analisi di profittabilità:', error);
      return {
        asin: bookData.asin,
        error: error.message
      };
    }
  }
  
  // Normalizza i dati di input
  normalizeInputData(bookData) {
    const inputData = {
      asin: bookData.asin,
      title: bookData.title || '',
      format: this.normalizeFormat(bookData.format),
      pages: this.extractNumber(bookData.pages) || 0,
      price: this.extractPrice(bookData.price) || 0,
      bsr: this.extractNumber(bookData.bsr) || 0,
      reviews: this.extractNumber(bookData.reviews) || 0,
      rating: this.extractNumber(bookData.rating) || 0,
      isColor: this.isColorBook(bookData),
      category: this.determineCategory(bookData),
      dim: bookData.dim || ''
    };
    
    return inputData;
  }
  
  // Normalizza il formato del libro
  normalizeFormat(formatString) {
    if (!formatString) return 'paperback';
    
    const format = formatString.toLowerCase();
    
    if (format.includes('kindle') || format.includes('ebook') || format.includes('e-book')) {
      return 'kindle';
    } else if (format.includes('hardcover') || format.includes('hardback') || format.includes('rilegato')) {
      return 'hardcover';
    } else {
      return 'paperback';
    }
  }
  
  // Determina se il libro è a colori
  isColorBook(bookData) {
    if (!bookData) return false;
    
    // Controlla se ci sono indicazioni esplicite
    if (bookData.isColor === true) return true;
    if (bookData.isColor === false) return false;
    
    // Controlla il formato
    const format = (bookData.format || '').toLowerCase();
    if (format.includes('color') || format.includes('colori')) return true;
    
    // Controlla il titolo
    const title = (bookData.title || '').toLowerCase();
    if (title.includes('color') || title.includes('colori') || 
        title.includes('illustrated') || title.includes('illustrato')) {
      return true;
    }
    
    // Controlla la categoria
    const category = this.determineCategory(bookData);
    if (category === 'children' || category === 'art' || category === 'photography') {
      return true;
    }
    
    return false;
  }
  
  // Determina la categoria del libro
  determineCategory(bookData) {
    if (!bookData) return 'default';
    
    const title = (bookData.title || '').toLowerCase();
    const category = (bookData.category || '').toLowerCase();
    
    // Controlla la categoria esplicita
    if (category.includes('fiction') || category.includes('narrativa')) return 'fiction';
    if (category.includes('non-fiction') || category.includes('saggistica')) return 'nonFiction';
    if (category.includes('technical') || category.includes('tecnico') || 
        category.includes('computer') || category.includes('science') || 
        category.includes('engineering')) return 'technical';
    if (category.includes('children') || category.includes('bambini') || 
        category.includes('kids')) return 'children';
    
    // Controlla il titolo
    if (title.includes('novel') || title.includes('romanzo') || 
        title.includes('fiction') || title.includes('story')) return 'fiction';
    if (title.includes('guide') || title.includes('guida') || 
        title.includes('how to') || title.includes('manual') || 
        title.includes('manuale')) return 'nonFiction';
    if (title.includes('programming') || title.includes('programmazione') || 
        title.includes('engineering') || title.includes('science') || 
        title.includes('technical')) return 'technical';
    if (title.includes('children') || title.includes('bambini') || 
        title.includes('kids') || title.includes('baby')) return 'children';
    
    return 'default';
  }
  
  // Estrai un numero da una stringa
  extractNumber(value) {
    if (typeof value === 'number') return value;
    if (!value) return null;
    
    const stringValue = String(value);
    const match = stringValue.match(/[\d,.]+/);
    
    if (match) {
      // Rimuovi caratteri non numerici tranne il punto decimale
      return parseFloat(match[0].replace(/[^\d.]/g, ''));
    }
    
    return null;
  }
  
  // Estrai il prezzo da una stringa
  extractPrice(priceString) {
    if (typeof priceString === 'number') return priceString;
    if (!priceString) return 0;
    
    const match = String(priceString).match(/[\d,.]+/);
    
    if (match) {
      // Rimuovi caratteri non numerici tranne il punto decimale
      return parseFloat(match[0].replace(/[^\d.]/g, ''));
    }
    
    return 0;
  }
  
  // Calcola i costi di stampa
  calculatePrintingCost(inputData) {
    if (inputData.format === 'kindle') return 0;
    
    const formatConfig = this.config.printingCosts[inputData.format] || this.config.printingCosts.paperback;
    const colorConfig = inputData.isColor ? formatConfig.color : formatConfig.blackAndWhite;
    
    const baseCost = colorConfig.baseCost;
    const pageCost = colorConfig.perPage * inputData.pages;
    
    return baseCost + pageCost;
  }
  
  // Calcola le royalty
  calculateRoyalty(inputData, printingCost) {
    const price = inputData.price;
    
    if (price <= 0) return 0;
    
    const royaltyPercentage = this.config.royaltyPercentages[inputData.format] || 0.6;
    
    if (inputData.format === 'kindle') {
      // Per Kindle, la royalty è una percentuale diretta del prezzo
      return price * royaltyPercentage;
    } else {
      // Per formati fisici, la royalty è una percentuale del prezzo meno i costi di stampa
      const royalty = (price * royaltyPercentage) - printingCost;
      return Math.max(0, royalty);
    }
  }
  
  // Stima le vendite giornaliere
  estimateDailySales(inputData) {
    const bsr = inputData.bsr;
    
    if (!bsr || bsr <= 0) return 0;
    
    const category = inputData.format === 'kindle' ? 'kindle' : 'books';
    
    return this.config.salesEstimation.calculateDailySales(bsr, category);
  }
  
  // Calcola l'ACOS di break-even
  calculateBreakEvenAcos(inputData, royalty) {
    const price = inputData.price;
    
    if (price <= 0 || royalty <= 0) return 0;
    
    // ACOS di break-even = (royalty / prezzo) * 100
    return (royalty / price) * 100;
  }
  
  // Calcola l'ACOS ottimale
  calculateOptimalAcos(breakEvenAcos) {
    if (breakEvenAcos <= 0) return 0;
    
    // ACOS ottimale = ACOS di break-even * ratio ottimale
    return breakEvenAcos * this.config.advertisingAnalysis.optimalAcosRatio;
  }
  
  // Calcola la spesa pubblicitaria giornaliera
  calculateDailyAdSpend(inputData, bestAcos, dailySales) {
    const price = inputData.price;
    
    if (price <= 0 || bestAcos <= 0 || dailySales <= 0) return 0;
    
    // Spesa pubblicitaria = (prezzo * vendite giornaliere * ACOS ottimale) / 100
    return (price * dailySales * bestAcos) / 100;
  }
  
  // Calcola l'incasso lordo giornaliero
  calculateDailyGross(inputData, dailySales) {
    const price = inputData.price;
    
    if (price <= 0 || dailySales <= 0) return 0;
    
    // Incasso lordo = prezzo * vendite giornaliere
    return price * dailySales;
  }
  
  // Calcola il profitto netto mensile
  calculateMonthlyNetProfit(royalty, dailySales, adSpend) {
    if (royalty <= 0 || dailySales <= 0) return 0;
    
    // Profitto netto = (royalty * vendite giornaliere * 30) - (spesa pubblicitaria * 30)
    return (royalty * dailySales * 30) - (adSpend * 30);
  }
  
  // Calcola il peso della pubblicità
  calculateAdWeight(adSpendTotal, monthlyGross) {
    if (monthlyGross <= 0) return 0;
    
    // Peso pubblicità = (spesa pubblicitaria totale / incasso lordo mensile) * 100
    return (adSpendTotal / monthlyGross) * 100;
  }
  
  // Calcola il CPC (costo per click)
  calculateCPC(adSpend, dailySales, category) {
    if (adSpend <= 0 || dailySales <= 0) return 0;
    
    // Ottieni il numero stimato di click per vendita
    const clicksPerSale = this.config.advertisingAnalysis.clicksPerSale[category] || 
                         this.config.advertisingAnalysis.clicksPerSale.default;
    
    // CPC = spesa pubblicitaria / (vendite giornaliere * click per vendita)
    return adSpend / (dailySales * clicksPerSale);
  }
  
  // Calcola lo score semplice
  calculateSimpleScore(inputData, results) {
    if (results.netProfit <= 0) return 0;
    
    // Fattori di ponderazione
    const profitWeight = 0.5;
    const salesWeight = 0.3;
    const reviewsWeight = 0.2;
    
    // Normalizza i valori
    const normalizedProfit = Math.min(results.netProfit / 5000, 1);
    const normalizedSales = Math.min(results.copiesPerDay / 20, 1);
    const normalizedReviews = Math.min(inputData.reviews / 500, 1);
    
    // Calcola lo score
    const score = (normalizedProfit * profitWeight) + 
                 (normalizedSales * salesWeight) + 
                 (normalizedReviews * reviewsWeight);
    
    // Scala lo score da 0 a 10
    return score * 10;
  }
  
  // Calcola lo score semplice 2
  calculateSimpleScore2(inputData, results) {
    if (results.netProfit <= 0) return 0;
    
    // Fattori di ponderazione
    const profitWeight = 0.4;
    const salesWeight = 0.2;
    const reviewsWeight = 0.2;
    const ratingWeight = 0.2;
    
    // Normalizza i valori
    const normalizedProfit = Math.min(results.netProfit / 5000, 1);
    const normalizedSales = Math.min(results.copiesPerDay / 20, 1);
    const normalizedReviews = Math.min(inputData.reviews / 500, 1);
    const normalizedRating = (inputData.rating - 1) / 4; // Scala da 1-5 a 0-1
    
    // Calcola lo score
    const score = (normalizedProfit * profitWeight) + 
                 (normalizedSales * salesWeight) + 
                 (normalizedReviews * reviewsWeight) + 
                 (normalizedRating * ratingWeight);
    
    // Scala lo score da 0 a 10
    return score * 10;
  }
  
  // Calcola lo score SN
  calculateSNScore(inputData, results) {
    if (results.netProfit <= 0) return 0;
    
    // Fattori di ponderazione
    const profitWeight = 0.4;
    const salesWeight = 0.2;
    const adWeightPenalty = 0.2;
    const competitionWeight = 0.2;
    
    // Normalizza i valori
    const normalizedProfit = Math.min(results.netProfit / 5000, 1);
    const normalizedSales = Math.min(results.copiesPerDay / 20, 1);
    
    // Penalità per peso pubblicitario elevato
    const adWeightNormalized = Math.max(0, 1 - (results.adWeight / 100));
    
    // Valuta la competizione (BSR più basso = più competizione)
    const competitionNormalized = inputData.bsr > 0 ? 
                                Math.min(inputData.bsr / 100000, 1) : 0;
    
    // Calcola lo score
    const score = (normalizedProfit * profitWeight) + 
                 (normalizedSales * salesWeight) + 
                 (adWeightNormalized * adWeightPenalty) + 
                 (competitionNormalized * competitionWeight);
    
    // Scala lo score da 0 a 15
    return score * 15;
  }
  
  // Calcola lo score SN2
  calculateSNScore2(inputData, results) {
    if (results.netProfit <= 0) return 0;
    
    // Fattori di ponderazione
    const profitWeight = 0.35;
    const salesWeight = 0.15;
    const adWeightPenalty = 0.15;
    const competitionWeight = 0.15;
    const reviewQualityWeight = 0.2;
    
    // Normalizza i valori
    const normalizedProfit = Math.min(results.netProfit / 5000, 1);
    const normalizedSales = Math.min(results.copiesPerDay / 20, 1);
    
    // Penalità per peso pubblicitario elevato
    const adWeightNormalized = Math.max(0, 1 - (results.adWeight / 100));
    
    // Valuta la competizione (BSR più basso = più competizione)
    const competitionNormalized = inputData.bsr > 0 ? 
                                Math.min(inputData.bsr / 100000, 1) : 0;
    
    // Qualità delle recensioni (combinazione di numero e rating)
    const reviewQuality = inputData.reviews > 0 ? 
                         (Math.min(inputData.reviews / 500, 1) * ((inputData.rating - 1) / 4)) : 0;
    
    // Calcola lo score
    const score = (normalizedProfit * profitWeight) + 
                 (normalizedSales * salesWeight) + 
                 (adWeightNormalized * adWeightPenalty) + 
                 (competitionNormalized * competitionWeight) + 
                 (reviewQuality * reviewQualityWeight);
    
    // Scala lo score da 0 a 15
    return score * 15;
  }
  
  // Arrotonda i valori numerici
  roundNumericValues(results) {
    const roundedResults = { ...results };
    
    for (const key in roundedResults) {
      if (typeof roundedResults[key] === 'number') {
        // Arrotonda a 2 decimali
        roundedResults[key] = Math.round(roundedResults[key] * 100) / 100;
      }
    }
    
    return roundedResults;
  }
}

// Esporta la classe
export default ProfitabilityAnalyzer;
