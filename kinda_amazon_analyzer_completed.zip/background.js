// background.js - Gestisce le richieste di rete e l'intercettazione delle API
console.log('[SW] Service Worker avviato ✅');

function cleanHtml(value) {
  return String(value || '')
    .replace(/<\/?[^>]+(>|$)/g, '')           // rimuove tag HTML
    .replace(/\s?class=['"][^'"]*['"]/g, '')  // rimuove class="..."
    .replace(/["']/g, '')                     // rimuove doppi e singoli apici
    .trim();
}

// Configurazione iniziale
let config = {
  apiEndpoints: {
    productDetails: '*://*.amazon.com/gp/product/ajax/*',
    technicalSpecs: '*://*.amazon.com/gp/product/features/*',
    searchResults: '*://*.amazon.com/s*',
    productPage: '*://*.amazon.com/dp/*',
    bestSellers: '*://*.amazon.com/gp/bestsellers/*'
  },
  markets: {
    'US': {
      domain: 'amazon.com',
      currency: '$'
    },
    'UK': {
      domain: 'amazon.co.uk',
      currency: '£'
    },
    'IT': {
      domain: 'amazon.it',
      currency: '€'
    },
    'DE': {
      domain: 'amazon.de',
      currency: '€'
    },
    'FR': {
      domain: 'amazon.fr',
      currency: '€'
    },
    'ES': {
      domain: 'amazon.es',
      currency: '€'
    }
  },
  defaultMarket: 'US'
};

// Inizializzazione
chrome.runtime.onInstalled.addListener(() => {
  console.log('Kinda Amazon Analyzer Pro installato');
  
  // Inizializza le impostazioni di default
  chrome.storage.local.set({
    kindaSettings: {
      market: config.defaultMarket,
      cacheExpiration: 86400000, // 24 ore in millisecondi
      enableProfitabilityAnalysis: true,
      enableGoogleTrends: false,
      maxConcurrentRequests: 5
    }
  });
  
  // Inizializza la cache
  chrome.storage.local.set({
    kindaCache: {}
  });
});

// Gestione dei messaggi dal content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[SW] Messaggio ricevuto:', message);
  
  if (message.type === 'ping') {
    sendResponse('pong');
    return true;
  }
  
  if (message.type === 'fetchProductDetails') {
    fetchProductDetails(message.asin)
      .then(data => {
        sendResponse({ success: true, data });
      })
      .catch(error => {
        console.error('Errore nel fetch dei dettagli prodotto:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
  
  if (message.type === 'clearCache') {
    clearCache()
      .then(() => {
        sendResponse({ success: true });
      })
      .catch(error => {
        console.error('Errore nella pulizia della cache:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});

// Funzione per intercettare le richieste
function interceptRequest(details) {
  // Memorizza l'URL per riferimento futuro
  chrome.storage.local.set({
    [`request_${details.requestId}`]: {
      url: details.url,
      timestamp: Date.now()
    }
  });
  
  // Non bloccare la richiesta originale
  return { cancel: false };
}

// Funzione per elaborare le risposte
async function processResponse(details) {
  try {
    // Recupera i dati della richiesta memorizzati
    const data = await chrome.storage.local.get(`request_${details.requestId}`);
    if (!data[`request_${details.requestId}`]) return;
    
    // Recupera il corpo della risposta
    const response = await fetch(details.url);
    const responseText = await response.text();
    
    try {
      const responseData = JSON.parse(responseText);
      
      // Elabora i dati in base al tipo di API
      if (details.url.includes('product/ajax')) {
        processProductDetails(responseData);
      } else if (details.url.includes('features')) {
        processTechnicalDetails(responseData);
      } else if (details.url.includes('bestsellers')) {
        processBestSellerData(responseData);
      }
    } catch (parseError) {
      console.error('Errore nel parsing JSON:', parseError);
      // Se non è JSON, potrebbe essere HTML
      if (details.url.includes('/dp/')) {
        processProductPageHTML(responseText);
      }
    }
    
    // Pulisci lo storage
    chrome.storage.local.remove(`request_${details.requestId}`);
  } catch (error) {
    console.error('Errore nell\'elaborazione della risposta:', error);
  }
}

// Elabora i dettagli del prodotto
function processProductDetails(data) {
  if (!data || !data.asin) return;
  
  const productData = {
    asin: data.asin,
    timestamp: Date.now()
  };
  
  // Estrai i dati rilevanti
  if (data.price) productData.price = data.price;
  if (data.rating) productData.rating = data.rating;
  if (data.reviews) productData.reviews = data.reviews;
  
  // Salva nella cache
  saveToCache(data.asin, 'productDetails', productData);
  
  // Notifica il content script
  notifyContentScript('productDetailsUpdated', {
    asin: data.asin,
    data: productData
  });
}

// Elabora i dettagli tecnici
function processTechnicalDetails(data) {
  if (!data || !data.asin) return;
  
  const technicalData = {
    asin: data.asin,
    timestamp: Date.now()
  };
  
  // Estrai i dati rilevanti
  if (data.details) {
    // Cerca il numero di pagine
    const pageDetail = data.details.find(detail => 
      detail.name.toLowerCase().includes('page') || 
      detail.name.toLowerCase().includes('pagine')
    );
    
    if (pageDetail) {
      technicalData.pages = parseInt(pageDetail.value.replace(/[^\d]/g, ''), 10);
    }
    
    // Cerca la data di pubblicazione
    const pubDateDetail = data.details.find(detail => 
      detail.name.toLowerCase().includes('publication') || 
      detail.name.toLowerCase().includes('pubblicazione')
    );
    
    if (pubDateDetail) {
      technicalData.publicationDate = pubDateDetail.value;
    }
    
    // Cerca l'editore
    const publisherDetail = data.details.find(detail => 
      detail.name.toLowerCase().includes('publisher') || 
      detail.name.toLowerCase().includes('editore')
    );
    
    if (publisherDetail) {
      technicalData.publisher = cleanHtml(publisherDetail.value);
      // Verifica se è self-published
      technicalData.isSelfPublished = /independently published|self published|createspace|kdp/i.test(publisherDetail.value);
    }
    
    // Cerca il formato
    const formatDetail = data.details.find(detail => 
      detail.name.toLowerCase().includes('format') || 
      detail.name.toLowerCase().includes('formato')
    );
    
    if (formatDetail && formatDetail.value) {
      let raw = formatDetail.value;

      // Se è HTML, estrai testo da eventuale markup
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = raw;
      raw = tempDiv.textContent || raw;

      // Pulisci il testo grezzo
      raw = raw
        .replace(/\s?class=['"][^'"]*['"]/gi, '')
        .replace(/["']/g, '')
        .replace(/[<>]/g, '')
        .replace(/\s+/g, ' ')
        .trim();

      // Categorizza il formato
      const validFormats = ['Paperback', 'Hardcover', 'Copertina flessibile', 'Copertina rigida', 'Kindle'];
      const match = validFormats.find(fmt => raw.toLowerCase().includes(fmt.toLowerCase()));

      technicalData.format = match || raw;
     }

  }
  
  // Salva nella cache
  saveToCache(data.asin, 'technicalDetails', technicalData);
  
  // Notifica il content script
  notifyContentScript('technicalDetailsUpdated', {
    asin: data.asin,
    data: technicalData
  });
}

// Elabora i dati di Best Seller Rank
function processBestSellerData(data) {
  if (!data || !data.asin) return;
  
  const bsrData = {
    asin: data.asin,
    timestamp: Date.now()
  };
  
  // Estrai i dati BSR
  if (data.salesRank) {
    bsrData.bsr = data.salesRank;
  }
  
  // Salva nella cache
  saveToCache(data.asin, 'bsrData', bsrData);
  
  // Notifica il content script
  notifyContentScript('bsrDataUpdated', {
    asin: data.asin,
    data: bsrData
  });
}

// Elabora la pagina prodotto HTML
function processProductPageHTML(html) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  
  // Estrai ASIN
  const asinMatch = html.match(/(?:"ASIN"|"asin")(?:\s*):(?:\s*)"([A-Z0-9]{10})"/i);
  const asin = asinMatch ? asinMatch[1] : null;
  
  if (!asin) return;
  
  const productData = {
    asin: asin,
    timestamp: Date.now()
  };
  
  // Estrai numero di pagine
  const pageMatches = [
    html.match(/(\d+)\s*pages/i),
    html.match(/(\d+)\s*pagine/i)
  ];

  for (const match of pageMatches) {
    if (match && match[1]) {
      productData.pages = parseInt(match[1], 10);
      break;
    }
  }
  
  // Estrai data di pubblicazione
  const dateMatches = [
    html.match(/Publication\s*(?:date|:)\s*(?::|;)?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4})/i),
    html.match(/Data\s*(?:di)?\s*(?:pubblicazione|:)\s*(?::|;)?\s*(\d{1,2}\s+[A-Za-z]+\s+\d{4})/i),
    html.match(/(?:pubblicato|published)\s*(?:il|on)?\s*:?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4}|\d{1,2}\s+[A-Za-z]+\s+\d{4})/i)
  ];
  
  for (const match of dateMatches) {
    if (match && match[1]) {
      productData.publicationDate = match[1];
      break;
    }
  }
  
  // Estrai editore
  const publisherMatches = [
    html.match(/Publisher\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i),
    html.match(/Editore\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i)
  ];
  
  for (const match of publisherMatches) {
    if (match && match[1]) {
      productData.publisher = cleanHtml(match[1]);
      // Verifica se è self-published
      productData.isSelfPublished = /independently published|self published|createspace|kdp/i.test(match[1]);
      break;
    }
  }
  
  // Estrai formato
  const formatMatches = [
    html.match(/Format\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i),
    html.match(/Formato\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i)
  ];
  
  for (const match of formatMatches) {
    if (match && match[1]) {
      const formatText = cleanHtml(match[1]);
      // Categorizza il formato
      const validFormats = ['Paperback', 'Hardcover', 'Copertina flessibile', 'Copertina rigida', 'Kindle'];
      const matchedFormat = validFormats.find(fmt => formatText.toLowerCase().includes(fmt.toLowerCase()));
      productData.format = matchedFormat || formatText;
      break;
    }
  }
  
  // Estrai BSR
  const bsrMatches = [
    html.match(/Best\s*Sellers\s*Rank\s*(?::|;)?\s*#?([\d,\.]+)/i),
    html.match(/Posizione\s*nella\s*classifica\s*Bestseller\s*(?:di\s*Amazon)?\s*(?::|;)?\s*#?([\d\.,]+)/i)
  ];
  
  for (const match of bsrMatches) {
    if (match && match[1]) {
      productData.bsr = '#' + match[1].replace(/[^\d]/g, '');
      break;
    }
  }
  
  // Salva nella cache
  saveToCache(asin, 'productPage', productData);
  
  // Notifica il content script
  notifyContentScript('productPageUpdated', {
    asin: asin,
    data: productData
  });
}

// Notifica il content script
function notifyContentScript(type, data) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0 && tabs[0].id) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: type,
        data: data
      });
    }
  });
}

// Salva nella cache
async function saveToCache(asin, dataType, data) {
  try {
    // Recupera la cache esistente
    const result = await chrome.storage.local.get('kindaCache');
    const cache = result.kindaCache || {};
    
    // Aggiorna la cache
    if (!cache[asin]) {
      cache[asin] = {};
    }
    
    cache[asin][dataType] = {
      ...data,
      timestamp: Date.now()
    };
    
    // Salva la cache aggiornata
    await chrome.storage.local.set({ kindaCache: cache });
    
    console.log(`[SW] Dati ${dataType} per ${asin} salvati nella cache`);
  } catch (error) {
    console.error('Errore nel salvataggio nella cache:', error);
  }
}

// Recupera dalla cache
async function getFromCache(asin, dataType) {
  try {
    // Recupera la cache esistente
    const result = await chrome.storage.local.get(['kindaCache', 'kindaSettings']);
    const cache = result.kindaCache || {};
    const settings = result.kindaSettings || {};
    
    // Verifica se i dati sono nella cache
    if (cache[asin] && cache[asin][dataType]) {
      const cachedData = cache[asin][dataType];
      const cacheExpiration = settings.cacheExpiration || 86400000; // 24 ore in millisecondi
      
      // Verifica se la cache è ancora valida
      if (Date.now() - cachedData.timestamp < cacheExpiration) {
        console.log(`[SW] Dati ${dataType} per ${asin} recuperati dalla cache`);
        return cachedData;
      }
    }
    
    return null;
  } catch (error) {
    console.error('Errore nel recupero dalla cache:', error);
    return null;
  }
}

// Pulisci la cache
async function clearCache() {
  try {
    await chrome.storage.local.set({ kindaCache: {} });
    console.log('[SW] Cache pulita con successo');
    return true;
  } catch (error) {
    console.error('Errore nella pulizia della cache:', error);
    throw error;
  }
}

// Funzione principale per recuperare i dettagli del prodotto
async function fetchProductDetails(asin) {
  if (!asin) {
    throw new Error('ASIN non valido');
  }
  
  try {
    // Verifica se i dati sono già nella cache
    const cachedData = await getFromCache(asin, 'productPage');
    if (cachedData) {
      return cachedData;
    }
    
    // Recupera i dati dalla pagina prodotto
    const url = `https://www.amazon.com/dp/${asin}`;
    const response = await fetch(url);
    const html = await response.text();
    
    // Estrai i dati dalla pagina prodotto
    const productData = extractProductDataFromHTML(html, asin);
    
    // Salva nella cache
    await saveToCache(asin, 'productPage', productData);
    
    return productData;
  } catch (error) {
    console.error(`Errore nel fetch dei dettagli per ${asin}:`, error);
    throw error;
  }
}

// Estrai i dati dalla pagina prodotto HTML
function extractProductDataFromHTML(html, asin) {
  const productData = {
    asin: asin,
    timestamp: Date.now()
  };
  
  // Estrai titolo
  const titleMatch = html.match(/<span id="productTitle"[^>]*>([^<]+)<\/span>/i);
  if (titleMatch && titleMatch[1]) {
    productData.title = cleanHtml(titleMatch[1]);
  }
  
  // Estrai prezzo
  const priceMatches = [
    html.match(/<span class="a-offscreen">([^<]+)<\/span>/i),
    html.match(/<span id="price"[^>]*>([^<]+)<\/span>/i),
    html.match(/<span class="a-price"[^>]*><span class="a-offscreen">([^<]+)<\/span>/i)
  ];
  
  for (const match of priceMatches) {
    if (match && match[1]) {
      productData.price = cleanHtml(match[1]);
      break;
    }
  }
  
  // Estrai numero di pagine
  const pageMatches = [
    html.match(/(\d+)\s*pages/i),
    html.match(/(\d+)\s*pagine/i)
  ];

  for (const match of pageMatches) {
    if (match && match[1]) {
      productData.pages = parseInt(match[1], 10);
      break;
    }
  }
  
  // Estrai data di pubblicazione
  const dateMatches = [
    html.match(/Publication\s*(?:date|:)\s*(?::|;)?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4})/i),
    html.match(/Data\s*(?:di)?\s*(?:pubblicazione|:)\s*(?::|;)?\s*(\d{1,2}\s+[A-Za-z]+\s+\d{4})/i),
    html.match(/(?:pubblicato|published)\s*(?:il|on)?\s*:?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4}|\d{1,2}\s+[A-Za-z]+\s+\d{4})/i)
  ];
  
  for (const match of dateMatches) {
    if (match && match[1]) {
      productData.publicationDate = cleanHtml(match[1]);
      break;
    }
  }
  
  // Estrai editore
  const publisherMatches = [
    html.match(/Publisher\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i),
    html.match(/Editore\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i)
  ];
  
  for (const match of publisherMatches) {
    if (match && match[1]) {
      productData.publisher = cleanHtml(match[1]);
      // Verifica se è self-published
      productData.isSelfPublished = /independently published|self published|createspace|kdp/i.test(match[1]);
      break;
    }
  }
  
  // Estrai formato
  const formatMatches = [
    html.match(/Format\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i),
    html.match(/Formato\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i)
  ];
  
  for (const match of formatMatches) {
    if (match && match[1]) {
      const formatText = cleanHtml(match[1]);
      // Categorizza il formato
      const validFormats = ['Paperback', 'Hardcover', 'Copertina flessibile', 'Copertina rigida', 'Kindle'];
      const matchedFormat = validFormats.find(fmt => formatText.toLowerCase().includes(fmt.toLowerCase()));
      productData.format = matchedFormat || formatText;
      break;
    }
  }
  
  // Estrai BSR
  const bsrMatches = [
    html.match(/Best\s*Sellers\s*Rank\s*(?::|;)?\s*#?([\d,\.]+)/i),
    html.match(/Posizione\s*nella\s*classifica\s*Bestseller\s*(?:di\s*Amazon)?\s*(?::|;)?\s*#?([\d\.,]+)/i)
  ];
  
  for (const match of bsrMatches) {
    if (match && match[1]) {
      productData.bsr = '#' + match[1].replace(/[^\d]/g, '');
      break;
    }
  }
  
  // Estrai rating
  const ratingMatch = html.match(/(\d+(\.\d+)?)\s*out\s*of\s*5\s*stars/i);
  if (ratingMatch && ratingMatch[1]) {
    productData.rating = ratingMatch[1];
  }
  
  // Estrai recensioni
  const reviewsMatch = html.match(/(\d+(\,\d+)?)\s*ratings/i);
  if (reviewsMatch && reviewsMatch[1]) {
    productData.reviews = reviewsMatch[1];
  }
  
  return productData;
}

// Funzione per estrarre dati dal tooltip DS Amazon Quick View
function extractDataFromTooltip(tooltipContent, asin) {
  if (!tooltipContent || !asin) return null;
  
  const tooltipData = {
    asin: asin,
    timestamp: Date.now()
  };
  
  // Estrai BSR
  const bsrMatch = tooltipContent.match(/Best\s*Sellers\s*Rank\s*(?::|;)?\s*#?([\d,\.]+)/i);
  if (bsrMatch && bsrMatch[1]) {
    tooltipData.bsr = '#' + bsrMatch[1].replace(/[^\d]/g, '');
  }
  
  // Estrai formato
  const formatMatch = tooltipContent.match(/Format\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i);
  if (formatMatch && formatMatch[1]) {
    const formatText = cleanHtml(formatMatch[1]);
    // Categorizza il formato
    const validFormats = ['Paperback', 'Hardcover', 'Copertina flessibile', 'Copertina rigida', 'Kindle'];
    const matchedFormat = validFormats.find(fmt => formatText.toLowerCase().includes(fmt.toLowerCase()));
    tooltipData.format = matchedFormat || formatText;
  }
  
  // Estrai numero di pagine
  const pageMatch = tooltipContent.match(/(\d+)\s*pages/i);
  if (pageMatch && pageMatch[1]) {
    tooltipData.pages = parseInt(pageMatch[1], 10);
  }
  
  // Estrai data di pubblicazione
  const dateMatch = tooltipContent.match(/Publication\s*(?:date|:)\s*(?::|;)?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4})/i);
  if (dateMatch && dateMatch[1]) {
    tooltipData.publicationDate = cleanHtml(dateMatch[1]);
  }
  
  // Estrai editore
  const publisherMatch = tooltipContent.match(/Publisher\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i);
  if (publisherMatch && publisherMatch[1]) {
    tooltipData.publisher = cleanHtml(publisherMatch[1]);
    // Verifica se è self-published
    tooltipData.isSelfPublished = /independently published|self published|createspace|kdp/i.test(publisherMatch[1]);
  }
  
  return tooltipData;
}
