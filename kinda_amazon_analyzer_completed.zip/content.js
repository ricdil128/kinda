// content.js - Gestisce l'interfaccia utente e l'interazione con la pagina Amazon
console.log('[Kinda] Content script caricato 🚀');
chrome.runtime.sendMessage({ type: 'ping' }, res => {
  console.log('[Kinda] Risposta dal SW:', res);
});

// Inizializzazione della cache locale con Dexie
const kindaDB = new Dexie('KindaCache');
kindaDB.version(1).stores({
  products: 'asin, data, timestamp'
});

// Configurazione
const config = {
  refreshInterval: 5000, // Intervallo di refresh in ms
  maxRetries: 5,         // Numero massimo di tentativi
  batchSize: 5,          // Dimensione del batch per richieste parallele
  markets: {
    'US': {
      domain: 'amazon.com',
      currency: '$'
    },
    'UK': {
      domain: 'amazon.co.uk',
      currency: '£'
    },
    'IT': {
      domain: 'amazon.it',
      currency: '€'
    },
    'DE': {
      domain: 'amazon.de',
      currency: '€'
    },
    'FR': {
      domain: 'amazon.fr',
      currency: '€'
    },
    'ES': {
      domain: 'amazon.es',
      currency: '€'
    }
  }
};

// Stato dell'applicazione
let appState = {
  isAnalyzing: false,
  currentMarket: 'US',
  productsData: [],
  processedItems: 0,
  totalItems: 0,
  retryCount: 0,
  refreshTimer: null,
  sortConfig: {
    column: null,
    direction: 'asc'
  },
  settings: {
    enableProfitabilityAnalysis: true,
    showSponsoredItems: true,
    cacheExpiration: 86400000 // 24 ore in millisecondi
  }
};

// Inizializzazione
observeSearchResults();

function observeSearchResults() {
  const observer = new MutationObserver(() => {
    const hasResults = document.querySelectorAll('div.s-result-item[data-asin]').length > 0;
    const btnExists = document.querySelector('#kinda-analyze-btn');
    if (hasResults && !btnExists) {
      console.log("[Kinda] Risultati trovati ✅");
      loadSettings().then(() => {
        addAnalyzeButton();
        setupMessageListeners();
      });
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

// Attendi che i risultati di ricerca siano caricati
function waitForSearchResults() {
  const itemFound = document.querySelector('div.s-result-item[data-asin]');
  if (!itemFound) {
    setTimeout(waitForSearchResults, 500);
    return;
  }
  
  // Carica le impostazioni
  loadSettings().then(() => {
    // Aggiungi il pulsante di analisi
    addAnalyzeButton();
    
    // Aggiungi listener per i messaggi dal background script
    setupMessageListeners();
  });
}

// Carica le impostazioni
async function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get('kindaSettings', (result) => {
      if (result.kindaSettings) {
        appState.settings = { ...appState.settings, ...result.kindaSettings };
        appState.currentMarket = result.kindaSettings.market || 'US';
      }
      resolve();
    });
  });
}

// Aggiungi il pulsante di analisi
function addAnalyzeButton() {
  if (document.querySelector("#kinda-analyze-btn")) return;

  const btn = document.createElement("button");
  btn.id = "kinda-analyze-btn";
  btn.innerText = "📊 Estrai dati con Kinda Pro";
  Object.assign(btn.style, {
    position: "fixed",
    bottom: "20px",
    left: "20px",
    zIndex: "9999",
    padding: "10px 15px",
    backgroundColor: "#111",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    boxShadow: "0 0 10px rgba(0,0,0,0.4)",
    fontFamily: "Arial, sans-serif"
  });

  btn.onclick = () => {
    if (appState.isAnalyzing) {
      stopAnalysis();
      btn.innerText = "📊 Estrai dati con Kinda Pro";
    } else {
      startAnalysis(btn);
      btn.innerText = "⌛ Analisi in corso...";
    }
  };

  document.body.appendChild(btn);
}

// Configura i listener per i messaggi
function setupMessageListeners() {
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'productDetailsUpdated' || 
        message.type === 'technicalDetailsUpdated' || 
        message.type === 'bsrDataUpdated' || 
        message.type === 'productPageUpdated') {
      
      console.log(`[Kinda] Messaggio ricevuto: ${message.type}`, message.data);

      if (message.data && message.data.format) {
        console.log(`[Kinda] ASIN ${message.data.asin} - Formato ricevuto:`, message.data.format);
      }

      updateProductData(message.data);
    }
  });
}

// Avvia l'analisi
function startAnalysis(btn) {
  appState.isAnalyzing = true;
  appState.productsData = [];
  appState.processedItems = 0;
  appState.retryCount = 0;
  
  // Ottieni tutti gli ASIN dalla pagina
  const items = document.querySelectorAll('div.s-result-item[data-asin]');
  appState.totalItems = items.length;
  
  if (appState.totalItems === 0) {
    alert('Nessun prodotto trovato nella pagina');
    stopAnalysis();
    btn.innerText = "📊 Estrai dati con Kinda Pro";
    return;
  }
  
  // Mostra l'indicatore di progresso
  showProgressIndicator();
  
  // Avvia il timer di refresh per attendere il caricamento dei dati BSR
  startAutoRefresh();
}

// Ferma l'analisi
function stopAnalysis() {
  appState.isAnalyzing = false;
  clearInterval(appState.refreshTimer);
  
  // Rimuovi l'indicatore di progresso
  const progressIndicator = document.querySelector('#kinda-progress-container');
  if (progressIndicator) {
    progressIndicator.remove();
  }
}

// Mostra l'indicatore di progresso
function showProgressIndicator() {
  // Rimuovi eventuali indicatori esistenti
  const existingIndicator = document.querySelector('#kinda-progress-container');
  if (existingIndicator) {
    existingIndicator.remove();
  }
  
  const container = document.createElement('div');
  container.id = 'kinda-progress-container';
  Object.assign(container.style, {
    position: 'fixed',
    top: '20px',
    right: '20px',
    zIndex: '9999',
    backgroundColor: '#fff',
    padding: '10px',
    borderRadius: '6px',
    boxShadow: '0 0 10px rgba(0,0,0,0.2)',
    fontFamily: 'Arial, sans-serif',
    width: '250px'
  });
  
  container.innerHTML = `
    <div style="margin-bottom: 5px; font-weight: bold;">Analisi Kinda in corso...</div>
    <div style="background-color: #f0f0f0; border-radius: 4px; height: 20px; overflow: hidden;">
      <div id="kinda-progress-bar" style="background-color: #4CAF50; height: 100%; width: 0%; transition: width 0.3s;"></div>
    </div>
    <div id="kinda-progress-text" style="margin-top: 5px; font-size: 12px;">0/${appState.totalItems} prodotti analizzati</div>
  `;
  
  document.body.appendChild(container);
}

// Aggiorna l'indicatore di progresso
function updateProgressIndicator() {
  const progressBar = document.querySelector('#kinda-progress-bar');
  const progressText = document.querySelector('#kinda-progress-text');
  
  if (progressBar && progressText) {
    const percentage = Math.round((appState.processedItems / appState.totalItems) * 100);
    progressBar.style.width = `${percentage}%`;
    progressText.textContent = `${appState.processedItems}/${appState.totalItems} prodotti analizzati`;
  }
}

// Avvia il refresh automatico
function startAutoRefresh() {
  clearInterval(appState.refreshTimer);
  
  appState.refreshTimer = setInterval(async () => {
    // Verifica se tutti i dati BSR sono stati caricati
    const allBsrLoaded = checkAllBsrLoaded();
    
    if (allBsrLoaded || appState.retryCount >= config.maxRetries) {
      // Se tutti i BSR sono caricati o abbiamo raggiunto il numero massimo di tentativi
      clearInterval(appState.refreshTimer);
      
      // Raccogli i dati dei prodotti
      await getSearchResultsData();
      
      // Mostra la tabella dei risultati
      displayDataTable(appState.productsData);
      
      // Aggiorna lo stato
      appState.isAnalyzing = false;
      
      // Aggiorna il pulsante
      const btn = document.querySelector('#kinda-analyze-btn');
      if (btn) {
        btn.innerText = "📊 Estrai dati con Kinda Pro";
      }
    } else {
      // Incrementa il contatore di tentativi
      appState.retryCount++;
      
      // Aggiorna l'indicatore di progresso
      updateProgressIndicator();
      
      console.log(`⏳ Attesa caricamento BSR... Tentativo ${appState.retryCount}/${config.maxRetries}`);
    }
  }, config.refreshInterval);
}

// Verifica se tutti i dati BSR sono stati caricati
function checkAllBsrLoaded() {
  const bsrElements = [...document.querySelectorAll('span.extension-rank')];
  return bsrElements.length > 0 && bsrElements.every(el => el.innerText.trim());
}

// Raccogli i dati dei risultati di ricerca
async function getSearchResultsData() {
  const items = document.querySelectorAll('div.s-result-item[data-asin]');
  const results = [];
  
  // Dividi gli elementi in batch per elaborazione parallela
  const batches = [];
  for (let i = 0; i < items.length; i += config.batchSize) {
    batches.push(Array.from(items).slice(i, i + config.batchSize));
  }
  
  // Elabora ogni batch in sequenza
  for (const batch of batches) {
    const batchPromises = batch.map(async (item) => {
      const asin = item.getAttribute('data-asin');
      if (!asin) return null;
      
      try {
        // Verifica se i dati sono già nella cache
        const cachedData = await getFromCache(asin);
        if (cachedData) {
          appState.processedItems++;
          updateProgressIndicator();
          return cachedData;
        }
        
        // Estrai i dati visibili dal DOM
        const visibleData = extractVisibleData(item, asin);
        
        // Recupera i dati aggiuntivi
        const additionalData = await fetchAdditionalData(asin);
        
        // Combina i dati
        const combinedData = { ...visibleData, ...additionalData };
        
        // Calcola i dati di profittabilità se abilitato
        if (appState.settings.enableProfitabilityAnalysis) {
          const profitabilityData = calculateProfitability(combinedData);
          Object.assign(combinedData, profitabilityData);
        }
        
        // Salva nella cache
        await saveToCache(asin, combinedData);
        
        // Aggiorna il contatore e l'indicatore di progresso
        appState.processedItems++;
        updateProgressIndicator();
        
        return combinedData;
      } catch (error) {
        console.error(`Errore nell'elaborazione di ${asin}:`, error);
        
        // Aggiorna il contatore e l'indicatore di progresso anche in caso di errore
        appState.processedItems++;
        updateProgressIndicator();
        
        return {
          asin,
          title: item.querySelector('h2')?.innerText.trim() || 'Errore',
          error: error.message
        };
      }
    });
    
    // Attendi il completamento del batch corrente
    const batchResults = await Promise.all(batchPromises);
    batchResults.forEach(book => {
      if (book && !results.some(b => b.asin === book.asin)) {
        results.push(book);
      }
    });
  }

  appState.productsData = results.filter(
    (book, index, self) => book && book.asin && self.findIndex(b => b.asin === book.asin) === index
);
  return results;
}

// Estrai i dati visibili dal DOM
function extractVisibleData(item, asin) {
  const isSponsored = !!item.innerText.match(/Sponsored/i);
  const title = item.querySelector('h2')?.innerText.trim() || '';
  const link = 'https://www.amazon.com' + (item.querySelector('h2 a')?.getAttribute('href') || '');
  const ratingRaw = item.querySelector('.a-icon-star-small span')?.innerText.trim() || '';
  const rating = ratingRaw.split(' ')[0];
  const reviews = item.querySelector('span.a-size-base.s-underline-text')?.innerText.trim() || '';
  const fullPrice = item.querySelector("span.a-price.a-text-price span:nth-child(2)")?.innerText.trim()
    || item.querySelector('.a-price .a-offscreen')?.innerText.trim() || '';

  const bsrEl = item.querySelector('span.extension-rank');
  const bsrText = /^\d/.test(bsrEl?.innerText?.trim() || '') ? bsrEl.innerText.trim() : '';

  const image = item.querySelector('img.s-image');
  const imgWidth = image?.naturalWidth || 0;
  const imgHeight = image?.naturalHeight || 1;
  const dim = (imgWidth / imgHeight) > 0.71 ? 'Oltre 6x9' : '≤6x9';
  
  return {
    asin,
    title,
    link,
    rating,
    reviews,
    price: fullPrice,
    bsr: bsrText,
    isSponsored,
    dim
  };
}

// Recupera dati aggiuntivi
async function fetchAdditionalData(asin) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: 'fetchProductDetails', asin },
      (response) => {
        if (response && response.success && response.data) {
          resolve(response.data);
        } else {
          resolve({});
        }
      }
    );
  });
}

function cleanBsr(val) {
  const str = typeof val === 'string' ? val : String(val || '');
  return parseInt(str.replace(/[^\d]/g, '') || '9999999', 10);
}

// Calcola i dati di profittabilità
function calculateProfitability(data) {
  // Valori di default se mancano dati
  const profitabilityData = {
    copiesPerDay: 0,
    bestAcos: 0,
    breakEvenAcos: 0,
    adSpend: 0,
    dailyGross: 0,
    monthlyGross: 0,
    netProfit: 0,
    adSpendTotal: 0,
    adWeight: 0,
    cpc: 0
  };
  
  try {
    // Estrai il prezzo numerico
    const price = typeof data.price === 'string'
                ? parseFloat(data.price.replace(/[^\d.,]/g, '').replace(',', '.')) || 0
                 : 0;
    
    // Estrai il BSR numerico
    const bsr = cleanBsr(data.bsr);
                if (bsr > 0) {
                     profitabilityData.copiesPerDay = Math.round(100000 / bsr);
           }
    
    // Calcola copie al giorno in base al BSR (formula semplificata)
    if (bsr > 0) {
      profitabilityData.copiesPerDay = Math.round(100000 / bsr);
    }
    
    // Calcola costo di stampa in base al numero di pagine
    let printingCost = 0;
    if (data.pages) {
      // Formula semplificata per il costo di stampa
      printingCost = (data.pages * 0.012) + 0.85;
    }
    
    // Calcola royalty (formula semplificata)
    let royalty = 0;
    if (price > 0) {
      royalty = price * 0.7 - printingCost;
      if (royalty < 0) royalty = 0;
    }
    
    // Calcola ACOS ottimale e di pareggio
    if (royalty > 0) {
      profitabilityData.breakEvenAcos = (royalty / price) * 100;
      profitabilityData.bestAcos = profitabilityData.breakEvenAcos * 0.67; // 67% del break-even
    }
    
    // Calcola spesa pubblicitaria giornaliera
    if (profitabilityData.copiesPerDay > 0 && profitabilityData.bestAcos > 0) {
      profitabilityData.adSpend = (price * profitabilityData.copiesPerDay * profitabilityData.bestAcos) / 100;
    }
    
    // Calcola incasso lordo giornaliero
    profitabilityData.dailyGross = price * profitabilityData.copiesPerDay;
    
    // Calcola incasso lordo mensile
    profitabilityData.monthlyGross = profitabilityData.dailyGross * 30;
    
    // Calcola profitto netto mensile
    profitabilityData.netProfit = (royalty * profitabilityData.copiesPerDay * 30) - (profitabilityData.adSpend * 30);
    
    // Calcola spesa pubblicitaria totale mensile
    profitabilityData.adSpendTotal = profitabilityData.adSpend * 30;
    
    // Calcola peso della pubblicità
    if (profitabilityData.monthlyGross > 0) {
      profitabilityData.adWeight = (profitabilityData.adSpendTotal / profitabilityData.monthlyGross) * 100;
    }
    
    // Calcola CPC (costo per click)
    if (profitabilityData.copiesPerDay > 0) {
      profitabilityData.cpc = profitabilityData.adSpend / (profitabilityData.copiesPerDay * 10); // Assumendo 10 click per vendita
    }
    
    // Arrotonda i valori per una migliore leggibilità
    Object.keys(profitabilityData).forEach(key => {
      if (typeof profitabilityData[key] === 'number') {
        profitabilityData[key] = Math.round(profitabilityData[key] * 100) / 100;
      }
    });
    
    // Aggiungi i dati di input utilizzati nei calcoli
    profitabilityData.inputPrice = price;
    profitabilityData.inputBsr = bsr;
    profitabilityData.printingCost = printingCost;
    profitabilityData.royalty = royalty;
    
  } catch (error) {
    console.error('Errore nel calcolo della profittabilità:', error);
  }
  
  return profitabilityData;
}

function escapeHtmlAttr(str) {
  return String(str || '')
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// Funzione per ordinare i dati
function sortData(data, column, direction) {
  return [...data].sort((a, b) => {
    let valueA, valueB;
    
    // Gestione speciale per colonne numeriche
    if (column === 'bsr') {
      valueA = cleanBsr(a[column]);
      valueB = cleanBsr(b[column]);
    } else if (column === 'price') {
      valueA = parseFloat((a[column] || '').replace(/[^\d.,]/g, '').replace(',', '.')) || 0;
      valueB = parseFloat((b[column] || '').replace(/[^\d.,]/g, '').replace(',', '.')) || 0;
    } else if (column === 'pages') {
      valueA = parseInt(a[column] || '0', 10);
      valueB = parseInt(b[column] || '0', 10);
    } else if (column === 'rating') {
      valueA = parseFloat(a[column] || '0');
      valueB = parseFloat(b[column] || '0');
    } else if (column === 'reviews') {
      valueA = parseInt((a[column] || '').replace(/[^\d]/g, '') || '0', 10);
      valueB = parseInt((b[column] || '').replace(/[^\d]/g, '') || '0', 10);
    } else if (column === 'copiesPerDay' || column === 'bestAcos' || column === 'breakEvenAcos' || 
               column === 'adSpend' || column === 'dailyGross' || column === 'monthlyGross' || 
               column === 'netProfit' || column === 'adWeight' || column === 'cpc') {
      valueA = parseFloat(a[column] || '0');
      valueB = parseFloat(b[column] || '0');
    } else {
      // Per colonne di testo
      valueA = String(a[column] || '').toLowerCase();
      valueB = String(b[column] || '').toLowerCase();
    }
    
    // Confronta i valori in base alla direzione
    if (direction === 'asc') {
      return valueA > valueB ? 1 : valueA < valueB ? -1 : 0;
    } else {
      return valueA < valueB ? 1 : valueA > valueB ? -1 : 0;
    }
  });
}

// Mostra la tabella dei dati
function displayDataTable(books) {
  const safe = (val) =>
      String(val || '')
        .replace(/<\/?[^>]+(>|$)/g, '')  // rimuove tag HTML
        .replace(/"/g, "'")              // sostituisce i doppi apici
        .trim();
  // Rimuovi eventuali tabelle esistenti
  const existingBox = document.querySelector("#kinda-box");
  if (existingBox) {
    existingBox.remove();
  }
  
  let html = `<h3 style='margin-top:0;'>📊 Risultati Kinda Pro</h3>`;
  html += `<label style='display:block; margin-bottom:10px;'><input type='checkbox' id='kinda-toggle-sponsored' ${appState.settings.showSponsoredItems ? 'checked' : ''}> Mostra libri sponsorizzati</label>`;
  
  // Aggiungi pulsanti per esportazione e altre funzionalità
  html += `
    <div style="margin-bottom: 10px;">
      <button id="kinda-export-csv" style="margin-right: 10px; padding: 5px 10px;">📥 Esporta CSV</button>
      <button id="kinda-clear-cache" style="margin-right: 10px; padding: 5px 10px;">🗑️ Pulisci Cache</button>
      <select id="kinda-market-selector" style="padding: 5px;">
        <option value="US" ${appState.currentMarket === 'US' ? 'selected' : ''}>Amazon.com (US)</option>
        <option value="UK" ${appState.currentMarket === 'UK' ? 'selected' : ''}>Amazon.co.uk (UK)</option>
        <option value="IT" ${appState.currentMarket === 'IT' ? 'selected' : ''}>Amazon.it (IT)</option>
        <option value="DE" ${appState.currentMarket === 'DE' ? 'selected' : ''}>Amazon.de (DE)</option>
        <option value="FR" ${appState.currentMarket === 'FR' ? 'selected' : ''}>Amazon.fr (FR)</option>
        <option value="ES" ${appState.currentMarket === 'ES' ? 'selected' : ''}>Amazon.es (ES)</option>
      </select>
    </div>
  `;
  
  // Crea la tabella
  html += `<div style="max-height: 500px; overflow-y: auto;"><table id='kinda-table' style='width:100%; border-collapse: collapse; font-size: 12px;'>`;
  
  // Funzione per generare l'intestazione della colonna con indicatore di ordinamento
  const getColumnHeader = (column, label) => {
    const isSorted = appState.sortConfig.column === column;
    const sortIndicator = isSorted 
      ? (appState.sortConfig.direction === 'asc' ? '↑' : '↓') 
      : '';
    
    return `<th class="sortable" data-column="${column}" style="cursor: pointer;">${label} ${sortIndicator}</th>`;
  };
  
  // Intestazione della tabella
  html += `<thead><tr style='background:#eee; position: sticky; top: 0;'>
    ${getColumnHeader('index', '#')}
    ${getColumnHeader('isSponsored', '$')}
    ${getColumnHeader('title', 'Titolo')}
    ${getColumnHeader('asin', 'ASIN')}
    ${getColumnHeader('price', 'Prezzo')}
    ${getColumnHeader('rating', 'Rating')}
    ${getColumnHeader('reviews', 'Recensioni')}
    ${getColumnHeader('bsr', 'BSR')}
    ${getColumnHeader('pages', 'Pagine')}
    ${getColumnHeader('publicationDate', 'Data')}
    ${getColumnHeader('format', 'Formato')}
    ${getColumnHeader('dim', 'Dim.')}
    ${getColumnHeader('isSelfPublished', 'SP')}
  `;
  
  // Aggiungi intestazioni per l'analisi di profittabilità se abilitata
  if (appState.settings.enableProfitabilityAnalysis) {
    html += `
      ${getColumnHeader('copiesPerDay', 'Copie/Giorno')}
      ${getColumnHeader('bestAcos', 'Miglior ACOS')}
      ${getColumnHeader('breakEvenAcos', 'ACOS B/E')}
      ${getColumnHeader('adSpend', 'Spesa Ads')}
      ${getColumnHeader('dailyGross', 'Lordo/Giorno')}
      ${getColumnHeader('monthlyGross', 'Lordo/Mese')}
      ${getColumnHeader('netProfit', 'Netto')}
      ${getColumnHeader('adWeight', 'Peso Ads')}
      ${getColumnHeader('cpc', 'CPC')}
    `;
  }
  
  html += `</tr></thead><tbody>`;
  
  // Ordina i dati se è configurato un ordinamento
  let sortedBooks = books;
  if (appState.sortConfig.column) {
    sortedBooks = sortData(books, appState.sortConfig.column, appState.sortConfig.direction);
  }
  
  // Righe della tabella
  sortedBooks.forEach((book, index) => {
    if (!book || !book.asin || !book.title) return;    
    const bsrStr = typeof book.bsr === 'string' ? book.bsr : String(book.bsr || '');
    const bsrVal = parseInt(bsrStr.replace(/[^\d]/g, '') || '9999999', 10); 
    const bsrColor = bsrVal < 100000 ? '#d6f5d6' : '#f5d6d6';
    const spMark = book.isSelfPublished ? '✅' : '';
    const cleanTitle = (book.title || '')
                .replace(/<\/?[^>]+(>|$)/g, '')     // rimuove tag HTML
                .replace(/"/g, "'")                 // sostituisce i doppi apici
               .trim();

    const words = cleanTitle.split(' ');
    const truncatedTitle = words.slice(0, 5).join(' ') + (words.length > 5 ? '...' : '');

    
    html += `<tr class='kinda-row' data-sponsored='${book.isSponsored}'>
      <td>${index + 1}</td>
      <td style="text-align:center;">${book.isSponsored ? '$' : ''}</td>
      <td style="max-width: 140px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${cleanTitle}">${truncatedTitle}</td>
      <td>${safe(book.asin)}</td>
                <td>${safe(book.price)}</td>
                <td>${safe(book.rating)}</td>
      <td>${safe(book.reviews)}</td>
                <td style='background:${bsrColor};'>${safe(book.bsr)}</td>
                <td>${safe(book.pages)}</td>
                <td>${safe(book.publicationDate)}</td>
                <td>${safe(book.format)}</td>
                <td>${safe(book.dim)}</td>
                <td>${spMark}</td>
    `;
    
    // Aggiungi celle per l'analisi di profittabilità se abilitata
    if (appState.settings.enableProfitabilityAnalysis) {
      html += `
        <td>${book.copiesPerDay || ''}</td>
        <td>${book.bestAcos ? book.bestAcos.toFixed(2) + '%' : ''}</td>
        <td>${book.breakEvenAcos ? book.breakEvenAcos.toFixed(2) + '%' : ''}</td>
        <td>${book.adSpend ? book.adSpend.toFixed(2) : ''}</td>
        <td>${book.dailyGross ? book.dailyGross.toFixed(2) : ''}</td>
        <td>${book.monthlyGross ? book.monthlyGross.toFixed(2) : ''}</td>
        <td>${book.netProfit ? book.netProfit.toFixed(2) : ''}</td>
        <td>${book.adWeight ? book.adWeight.toFixed(2) + '%' : ''}</td>
        <td>${book.cpc ? book.cpc.toFixed(2) : ''}</td>
      `;
    }
    
    html += `</tr>`;
  });
  
  html += `</tbody></table></div>`;
  
  // Crea il box
  const box = document.createElement("div");
  box.id = "kinda-box";
  Object.assign(box.style, {
    position: "fixed",
    bottom: "80px",
    right: "20px",
    width: "880px",
    maxHeight: "70vh",
    overflowY: "auto",
    background: "#fff",
    border: "2px solid #ccc",
    borderRadius: "10px",
    padding: "16px",
    zIndex: "999999",
    fontFamily: "Arial, sans-serif",
    boxShadow: "0 4px 10px rgba(0,0,0,0.25)"
  });
  
  // Aggiungi pulsante di chiusura
  const closeBtn = document.createElement("button");
  closeBtn.innerText = "×";
  Object.assign(closeBtn.style, {
    position: "absolute",
    top: "5px",
    right: "10px",
    border: "none",
    background: "none",
    fontSize: "16px",
    cursor: "pointer"
  });
  closeBtn.onclick = () => box.remove();
  
  box.innerHTML = html;
  box.appendChild(closeBtn);
  document.body.appendChild(box);
  
  // Aggiungi event listener
  setupTableEventListeners();
}

// Configura gli event listener per la tabella
function setupTableEventListeners() {
  // Toggle per elementi sponsorizzati
  document.querySelector("#kinda-toggle-sponsored")?.addEventListener("change", e => {
    appState.settings.showSponsoredItems = e.target.checked;
    
    document.querySelectorAll(".kinda-row").forEach(row => {
      const isSponsored = row.getAttribute("data-sponsored") === "true";
      row.style.display = e.target.checked || !isSponsored ? "" : "none";
    });
    
    // Salva l'impostazione
    chrome.storage.local.get('kindaSettings', (result) => {
      const settings = result.kindaSettings || {};
      settings.showSponsoredItems = e.target.checked;
      chrome.storage.local.set({ kindaSettings: settings });
    });
  });
  
  // Esportazione CSV
  document.querySelector("#kinda-export-csv")?.addEventListener("click", () => {
    exportToCsv();
  });
  
  // Pulizia cache
  document.querySelector("#kinda-clear-cache")?.addEventListener("click", () => {
    clearCache();
  });
  
  // Selezione mercato
  document.querySelector("#kinda-market-selector")?.addEventListener("change", e => {
    appState.currentMarket = e.target.value;
    
    // Salva l'impostazione
    chrome.storage.local.get('kindaSettings', (result) => {
      const settings = result.kindaSettings || {};
      settings.market = e.target.value;
      chrome.storage.local.set({ kindaSettings: settings });
    });
  });
  
  // Ordinamento colonne
  document.querySelectorAll('.sortable').forEach(th => {
    th.addEventListener('click', () => {
      const column = th.getAttribute('data-column');
      let direction = 'asc';
      
      // Se la colonna è già ordinata, inverti la direzione
      if (appState.sortConfig.column === column) {
        direction = appState.sortConfig.direction === 'asc' ? 'desc' : 'asc';
      }
      
      // Aggiorna la configurazione di ordinamento
      appState.sortConfig = { column, direction };
      
      // Aggiorna la tabella
      displayDataTable(appState.productsData);
    });
  });
}

// Esporta i dati in formato CSV
function exportToCsv() {
  const books = appState.productsData;
  if (!books || books.length === 0) return;
  
  // Definisci le intestazioni
  let headers = ['#', 'Sponsorizzato', 'Titolo', 'ASIN', 'Prezzo', 'Rating', 'Recensioni', 'BSR', 
                'Pagine', 'Data Pubblicazione', 'Formato', 'Dimensione', 'Self Published'];
  
  // Aggiungi intestazioni per l'analisi di profittabilità se abilitata
  if (appState.settings.enableProfitabilityAnalysis) {
    headers = headers.concat(['Copie/Giorno', 'Miglior ACOS', 'ACOS Break-Even', 'Spesa Ads', 
                             'Lordo/Giorno', 'Lordo/Mese', 'Netto', 'Peso Ads', 'CPC']);
  }
  
  // Crea le righe
  const rows = books.map((book, index) => {
    let row = [
      index + 1,
      book.isSponsored ? 'Sì' : 'No',
      book.title || '',
      book.asin || '',
      book.price || '',
      book.rating || '',
      book.reviews || '',
      book.bsr || '',
      book.pages || '',
      book.publicationDate || '',
      book.format || '',
      book.dim || '',
      book.isSelfPublished ? 'Sì' : 'No'
    ];
    
    // Aggiungi dati di profittabilità se abilitati
    if (appState.settings.enableProfitabilityAnalysis) {
      row = row.concat([
        book.copiesPerDay || '',
        book.bestAcos ? book.bestAcos.toFixed(2) + '%' : '',
        book.breakEvenAcos ? book.breakEvenAcos.toFixed(2) + '%' : '',
        book.adSpend ? book.adSpend.toFixed(2) : '',
        book.dailyGross ? book.dailyGross.toFixed(2) : '',
        book.monthlyGross ? book.monthlyGross.toFixed(2) : '',
        book.netProfit ? book.netProfit.toFixed(2) : '',
        book.adWeight ? book.adWeight.toFixed(2) + '%' : '',
        book.cpc ? book.cpc.toFixed(2) : ''
      ]);
    }
    
    return row;
  });
  
  // Unisci intestazioni e righe
  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
  ].join('\n');
  
  // Crea un blob e un link per il download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `kinda_export_${new Date().toISOString().slice(0, 10)}.csv`);
  link.style.display = 'none';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Pulisci la cache
function clearCache() {
  // Pulisci la cache locale
  kindaDB.products.clear()
    .then(() => {
      console.log('Cache locale pulita');
    })
    .catch(error => {
      console.error('Errore nella pulizia della cache locale:', error);
    });
  
  // Pulisci la cache dell'estensione
  chrome.runtime.sendMessage({ type: 'clearCache' }, (response) => {
    if (response && response.success) {
      console.log('Cache dell\'estensione pulita');
      alert('Cache pulita con successo');
    } else {
      console.error('Errore nella pulizia della cache dell\'estensione');
    }
  });
}

// Salva i dati nella cache locale
async function saveToCache(asin, data) {
  try {
    await kindaDB.products.put({
      asin,
      data,
      timestamp: Date.now()
    });
  } catch (error) {
    console.error(`Errore nel salvataggio nella cache per ${asin}:`, error);
  }
}

// Recupera i dati dalla cache locale
async function getFromCache(asin) {
  try {
    const cachedItem = await kindaDB.products
      .where('asin')
      .equals(asin)
      .first();
    
    if (cachedItem) {
      const cacheExpiration = appState.settings.cacheExpiration || 86400000; // Default 24 ore
      
      if (Date.now() - cachedItem.timestamp < cacheExpiration) {
        return cachedItem.data;
      }
    }
    
    return null;
  } catch (error) {
    console.error(`Errore nel recupero dalla cache per ${asin}:`, error);
    return null;
  }
}

// Aggiorna i dati di un prodotto
function updateProductData(newData) {
  if (!newData || !newData.asin) return;
  
  // Cerca il prodotto nell'array
  const index = appState.productsData.findIndex(item => item.asin === newData.asin);
  
  if (index !== -1) {
    // Aggiorna i dati esistenti
    appState.productsData[index] = {
      ...appState.productsData[index],
      ...newData
    };
    
    // Ricalcola i dati di profittabilità se abilitato
    if (appState.settings.enableProfitabilityAnalysis) {
      const profitabilityData = calculateProfitability(appState.productsData[index]);
      Object.assign(appState.productsData[index], profitabilityData);
    }
  } else {
    // Aggiungi il nuovo prodotto
    appState.productsData.push(newData);
  }
}
