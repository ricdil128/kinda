// api-interceptor.js - Gestisce l'intercettazione avanzata delle API interne di Amazon
console.log('[Kinda] api-interceptor.js caricato ✅');
// Configurazione delle API da intercettare
const API_CONFIG = {
  // API per i dettagli del prodotto
  productDetails: {
    patterns: [
      '*://*.amazon.com/gp/product/ajax/*',
      '*://*.amazon.com/gp/aod/ajax/*',
      '*://*.amazon.com/hz/reviews-render/ajax/*'
    ],
    handler: processProductDetailsApi
  },
  // API per le specifiche tecniche
  technicalSpecs: {
    patterns: [
      '*://*.amazon.com/gp/product/features/*',
      '*://*.amazon.com/gp/product/specifications/*'
    ],
    handler: processTechnicalSpecsApi
  },
  // API per i dati di Best Seller Rank
  bestSellers: {
    patterns: [
      '*://*.amazon.com/gp/bestsellers/*',
      '*://*.amazon.com/gp/new-releases/*'
    ],
    handler: processBestSellerApi
  },
  // API per i dati di ricerca
  search: {
    patterns: [
      '*://*.amazon.com/s?*',
      '*://*.amazon.com/s/*',
      '*://*.amazon.com/gp/search/*'
    ],
    handler: processSearchApi
  },
  // API per i dati del prodotto
  productPage: {
    patterns: [
      '*://*.amazon.com/dp/*',
      '*://*.amazon.com/gp/product/*'
    ],
    handler: processProductPageApi
  }
};

// Inizializzazione dell'interceptor
function initApiInterceptor() {
  console.log('Inizializzazione API Interceptor');
  
  // Registra gli handler per le richieste di rete
  setupNetworkListeners();
  
  // Monkey patch delle funzioni fetch e XMLHttpRequest
  monkeyPatchFetch();
  monkeyPatchXhr();
}

// Configura i listener per le richieste di rete
function setupNetworkListeners() {
  // Raccogli tutti i pattern da monitorare
  const allPatterns = Object.values(API_CONFIG).flatMap(api => api.patterns);
  
  // Registra il listener per le richieste
}

// Intercetta le richieste di rete
function interceptRequest(details) {
  // Memorizza l'URL per riferimento futuro
  chrome.storage.local.set({
    [`request_${details.requestId}`]: {
      url: details.url,
      timestamp: Date.now()
    }
  });
  
  // Non bloccare la richiesta originale
  return { cancel: false };
}

// Elabora le risposte di rete
async function processResponse(details) {
  try {
    // Recupera i dati della richiesta memorizzati
    const data = await chrome.storage.local.get(`request_${details.requestId}`);
    if (!data[`request_${details.requestId}`]) return;
    
    // Recupera il corpo della risposta
    const response = await fetch(details.url);
    const responseText = await response.text();
    
    // Determina quale handler utilizzare in base all'URL
    for (const [apiType, config] of Object.entries(API_CONFIG)) {
      if (config.patterns.some(pattern => matchUrlPattern(details.url, pattern))) {
        try {
          // Prova a parsare come JSON
          const responseData = JSON.parse(responseText);
          config.handler(responseData, details.url);
        } catch (parseError) {
          // Se non è JSON, passa il testo
          config.handler(responseText, details.url);
        }
        break;
      }
    }
    
    // Pulisci lo storage
    chrome.storage.local.remove(`request_${details.requestId}`);
  } catch (error) {
    console.error('Errore nell\'elaborazione della risposta:', error);
  }
}

// Verifica se un URL corrisponde a un pattern
function matchUrlPattern(url, pattern) {
  // Converti il pattern in una regex
  const regexPattern = pattern
    .replace(/\./g, '\\.')
    .replace(/\*/g, '.*')
    .replace(/\?/g, '\\?');
  
  return new RegExp(`^${regexPattern}$`).test(url);
}

// Monkey patch della funzione fetch
function monkeyPatchFetch() {
  const originalFetch = window.fetch;
  
  window.fetch = async function(resource, init) {
    // Chiama la funzione originale
    const response = await originalFetch(resource, init);
    
    // Se la richiesta è verso un'API Amazon di interesse
    if (typeof resource === 'string' && isAmazonApiUrl(resource)) {
      try {
        // Clona la risposta per poterla leggere
        const responseClone = response.clone();
        const contentType = responseClone.headers.get('content-type');
        
        if (contentType && contentType.includes('application/json')) {
          const data = await responseClone.json();
          processInterceptedData(resource, data);
        } else {
          const text = await responseClone.text();
          processInterceptedData(resource, text);
        }
      } catch (e) {
        // Ignora errori di parsing
        console.error('Errore nel processing della risposta intercettata:', e);
      }
    }
    
    // Restituisci la risposta originale
    return response;
  };
}

// Monkey patch di XMLHttpRequest
function monkeyPatchXhr() {
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;
  
  XMLHttpRequest.prototype.open = function(method, url, ...args) {
    this._kindaUrl = url;
    return originalOpen.apply(this, [method, url, ...args]);
  };
  
  XMLHttpRequest.prototype.send = function(...args) {
    if (this._kindaUrl && isAmazonApiUrl(this._kindaUrl)) {
      const originalOnLoad = this.onload;
      
      this.onload = function(...loadArgs) {
        try {
          const contentType = this.getResponseHeader('content-type');
          
          if (contentType && contentType.includes('application/json')) {
            const data = JSON.parse(this.responseText);
            processInterceptedData(this._kindaUrl, data);
          } else {
            processInterceptedData(this._kindaUrl, this.responseText);
          }
        } catch (e) {
          // Ignora errori di parsing
          console.error('Errore nel processing della risposta XHR intercettata:', e);
        }
        
        if (originalOnLoad) {
          return originalOnLoad.apply(this, loadArgs);
        }
      };
    }
    
    return originalSend.apply(this, args);
  };
}

// Verifica se un URL è un'API Amazon di interesse
function isAmazonApiUrl(url) {
  return Object.values(API_CONFIG).some(api => 
    api.patterns.some(pattern => matchUrlPattern(url, pattern))
  );
}

// Elabora i dati intercettati
function processInterceptedData(url, data) {
  // Determina quale handler utilizzare in base all'URL
  for (const [apiType, config] of Object.entries(API_CONFIG)) {
    if (config.patterns.some(pattern => matchUrlPattern(url, pattern))) {
      config.handler(data, url);
      break;
    }
  }
}

// Handler per l'API dei dettagli del prodotto
function processProductDetailsApi(data, url) {
  try {
    // Estrai l'ASIN dall'URL
    const asinMatch = url.match(/\/([A-Z0-9]{10})(?:\/|\?|$)/);
    const asin = asinMatch ? asinMatch[1] : extractAsinFromData(data);
    
    if (!asin) {
      console.warn('Impossibile estrarre ASIN dai dati o dall\'URL:', url);
      return;
    }
    
    const productData = {
      asin,
      timestamp: Date.now(),
      source: 'productDetailsApi'
    };
    
    // Estrai i dati in base al formato della risposta
    if (typeof data === 'object') {
      // Estrai prezzo
      if (data.price) productData.price = data.price;
      if (data.priceAmount) productData.price = data.priceAmount;
      if (data.displayPrice) productData.price = data.displayPrice;
      
      // Estrai rating
      if (data.rating) productData.rating = data.rating;
      if (data.averageRating) productData.rating = data.averageRating;
      if (data.averageStarRating) productData.rating = data.averageStarRating;
      
      // Estrai recensioni
      if (data.reviewCount) productData.reviews = data.reviewCount;
      if (data.totalReviewCount) productData.reviews = data.totalReviewCount;
      
      // Estrai BSR
      if (data.salesRank) productData.bsr = data.salesRank;
      if (data.bestSellerRank) productData.bsr = data.bestSellerRank;
      if (data.salesRankings) {
        const bsrData = extractBsrFromSalesRankings(data.salesRankings);
        if (bsrData) productData.bsr = bsrData;
      }
    } else if (typeof data === 'string') {
      // Estrai dati dal testo HTML
      const priceMatch = data.match(/price"[^>]*>([^<]+)<\/span>/i);
      if (priceMatch) productData.price = priceMatch[1].trim();
      
      const ratingMatch = data.match(/averageRating"[^>]*>([^<]+)<\/span>/i);
      if (ratingMatch) productData.rating = parseFloat(ratingMatch[1]);
      
      const reviewMatch = data.match(/reviewCount"[^>]*>([^<]+)<\/span>/i);
      if (reviewMatch) productData.reviews = parseInt(reviewMatch[1].replace(/[^\d]/g, ''), 10);
      
      const bsrMatch = data.match(/Best Sellers Rank(?:[^#]*)#([0-9,]+)/i);
      if (bsrMatch) productData.bsr = parseInt(bsrMatch[1].replace(/,/g, ''), 10);
    }
    
    // Salva i dati
    saveInterceptedData(asin, 'productDetails', productData);
    
    // Notifica il content script
    notifyContentScript('productDetailsUpdated', productData);
  } catch (error) {
    console.error('Errore nell\'elaborazione dei dati dell\'API dei dettagli del prodotto:', error);
  }
}

// Handler per l'API delle specifiche tecniche
function processTechnicalSpecsApi(data, url) {
  try {
    // Estrai l'ASIN dall'URL
    const asinMatch = url.match(/\/([A-Z0-9]{10})(?:\/|\?|$)/);
    const asin = asinMatch ? asinMatch[1] : extractAsinFromData(data);
    
    if (!asin) {
      console.warn('Impossibile estrarre ASIN dai dati o dall\'URL:', url);
      return;
    }
    
    const technicalData = {
      asin,
      timestamp: Date.now(),
      source: 'technicalSpecsApi'
    };
    
    // Estrai i dati in base al formato della risposta
    if (typeof data === 'object') {
      // Cerca il numero di pagine
      if (data.details) {
        const pageDetail = findDetailByName(data.details, ['page', 'pagine', 'pages']);
        if (pageDetail) {
          technicalData.pages = extractNumberFromString(pageDetail.value);
        }
        
        // Cerca la data di pubblicazione
        const pubDateDetail = findDetailByName(data.details, ['publication', 'pubblicazione', 'release date']);
        if (pubDateDetail) {
          technicalData.publicationDate = pubDateDetail.value;
        }
        
        // Cerca l'editore
        const publisherDetail = findDetailByName(data.details, ['publisher', 'editore']);
        if (publisherDetail) {
          technicalData.publisher = publisherDetail.value;
          // Verifica se è self-published
          technicalData.isSelfPublished = isSelfPublished(publisherDetail.value);
        }
        
        // Cerca il formato
        const formatDetail = findDetailByName(data.details, ['format', 'formato']);
        if (formatDetail && formatDetail.value) {
          const tempDiv = document.createElement('div');
          tempDiv.innerHTML = formatDetail.value;

          let raw = tempDiv.textContent || '';

          raw = raw
            .replace(/\s?class=['"][^'"]*['"]/gi, '')  // rimuove class=
            .replace(/["']/g, '')                      // rimuove apici
            .replace(/[<>]/g, '')                      // rimuove < e >
            .replace(/\s+/g, ' ')                      // normalizza spazi
            .trim();

          const validFormats = ['Paperback', 'Hardcover', 'Copertina flessibile', 'Copertina rigida', 'Kindle'];
          const match = validFormats.find(fmt => raw.toLowerCase().includes(fmt.toLowerCase()));

          technicalData.format = match || raw;
          console.log(`[Kinda] Format estratto per ASIN ${asin}:`, technicalData.format);
        }
      }
      
      // Cerca nelle specifiche tecniche
      if (data.technicalSpecifications || data.specifications) {
        const specs = data.technicalSpecifications || data.specifications;
        
        // Itera attraverso le specifiche
        for (const spec of specs) {
          if (spec.name.toLowerCase().includes('page')) {
            technicalData.pages = extractNumberFromString(spec.value);
          } else if (spec.name.toLowerCase().includes('publication')) {
            technicalData.publicationDate = spec.value;
          } else if (spec.name.toLowerCase().includes('publisher')) {
            technicalData.publisher = spec.value;
            technicalData.isSelfPublished = isSelfPublished(spec.value);
          } else if (spec.name.toLowerCase().includes('format')) {
            technicalData.format = spec.value;
          }
        }
      }
    } else if (typeof data === 'string') {
      // Estrai dati dal testo HTML
      const pageMatch = data.match(/(\d+)\s*pages/i) || data.match(/(\d+)\s*pagine/i);
      if (pageMatch) technicalData.pages = parseInt(pageMatch[1], 10);
      
      const dateMatch = data.match(/Publication\s*(?:date|:)\s*(?::|;)?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4})/i) ||
                       data.match(/Data\s*(?:di)?\s*(?:pubblicazione|:)\s*(?::|;)?\s*(\d{1,2}\s+[A-Za-z]+\s+\d{4})/i);
      if (dateMatch) technicalData.publicationDate = dateMatch[1];
      
      const publisherMatch = data.match(/Publisher\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i) ||
                            data.match(/Editore\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i);
      if (publisherMatch) {
        technicalData.publisher = publisherMatch[1].trim();
        technicalData.isSelfPublished = isSelfPublished(technicalData.publisher);
      }
      
      const formatMatch = data.match(/Format\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i) ||
                         data.match(/Formato\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i);
      if (formatMatch) technicalData.format = formatMatch[1].trim();
    }
    
    // Salva i dati
    saveInterceptedData(asin, 'technicalSpecs', technicalData);
    
    // Notifica il content script
    notifyContentScript('technicalDetailsUpdated', technicalData);
  } catch (error) {
    console.error('Errore nell\'elaborazione dei dati dell\'API delle specifiche tecniche:', error);
  }
}

// Handler per l'API dei Best Seller
function processBestSellerApi(data, url) {
  try {
    // Estrai l'ASIN dall'URL
    const asinMatch = url.match(/\/([A-Z0-9]{10})(?:\/|\?|$)/);
    const asin = asinMatch ? asinMatch[1] : extractAsinFromData(data);
    
    if (!asin) {
      console.warn('Impossibile estrarre ASIN dai dati o dall\'URL:', url);
      return;
    }
    
    const bsrData = {
      asin,
      timestamp: Date.now(),
      source: 'bestSellerApi'
    };
    
    // Estrai i dati in base al formato della risposta
    if (typeof data === 'object') {
      // Estrai BSR
      if (data.salesRank) bsrData.bsr = data.salesRank;
      if (data.bestSellerRank) bsrData.bsr = data.bestSellerRank;
      if (data.rank) bsrData.bsr = data.rank;
      
      // Estrai categoria
      if (data.category) bsrData.category = data.category;
      if (data.categoryName) bsrData.category = data.categoryName;
    } else if (typeof data === 'string') {
      // Estrai dati dal testo HTML
      const bsrMatch = data.match(/Best Sellers Rank(?:[^#]*)#([0-9,]+)/i) ||
                      data.match(/Classifica Bestseller(?:[^#]*)#([0-9.]+)/i);
      if (bsrMatch) bsrData.bsr = parseInt(bsrMatch[1].replace(/[,\.]/g, ''), 10);
      
      const categoryMatch = data.match(/Best Sellers Rank[^>]*in\s+([^<]+)</i) ||
                           data.match(/Classifica Bestseller[^>]*in\s+([^<]+)</i);
      if (categoryMatch) bsrData.category = categoryMatch[1].trim();
    }
    
    // Salva i dati
    saveInterceptedData(asin, 'bestSeller', bsrData);
    
    // Notifica il content script
    notifyContentScript('bsrDataUpdated', bsrData);
  } catch (error) {
    console.error('Errore nell\'elaborazione dei dati dell\'API dei Best Seller:', error);
  }
}

// Handler per l'API di ricerca
function processSearchApi(data, url) {
  try {
    // Estrai i dati di ricerca
    if (typeof data === 'object' && data.results) {
      // Itera attraverso i risultati
      for (const result of data.results) {
        if (result.asin) {
          const searchData = {
            asin: result.asin,
            timestamp: Date.now(),
            source: 'searchApi'
          };
          
          // Estrai i dati disponibili
          if (result.title) searchData.title = result.title;
          if (result.price) searchData.price = result.price;
          if (result.rating) searchData.rating = result.rating;
          if (result.reviewCount) searchData.reviews = result.reviewCount;
          if (result.salesRank) searchData.bsr = result.salesRank;
          
          // Salva i dati
          saveInterceptedData(result.asin, 'search', searchData);
          
          // Notifica il content script
          notifyContentScript('searchResultUpdated', searchData);
        }
      }
    } else if (typeof data === 'string') {
      // Estrai dati dal testo HTML
      const productElements = extractProductElementsFromHtml(data);
      
      for (const product of productElements) {
        if (product.asin) {
          // Salva i dati
          saveInterceptedData(product.asin, 'search', {
            ...product,
            timestamp: Date.now(),
            source: 'searchApi'
          });
          
          // Notifica il content script
          notifyContentScript('searchResultUpdated', product);
        }
      }
    }
  } catch (error) {
    console.error('Errore nell\'elaborazione dei dati dell\'API di ricerca:', error);
  }
}

// Handler per l'API della pagina prodotto
function processProductPageApi(data, url) {
  try {
    // Estrai l'ASIN dall'URL
    const asinMatch = url.match(/\/([A-Z0-9]{10})(?:\/|\?|$)/);
    const asin = asinMatch ? asinMatch[1] : extractAsinFromData(data);
    
    if (!asin) {
      console.warn('Impossibile estrarre ASIN dai dati o dall\'URL:', url);
      return;
    }
    
    const productData = {
      asin,
      timestamp: Date.now(),
      source: 'productPageApi'
    };
    
    // Estrai i dati in base al formato della risposta
    if (typeof data === 'object') {
      // Estrai dati dal JSON
      if (data.title) productData.title = data.title;
      if (data.price) productData.price = data.price;
      if (data.rating) productData.rating = data.rating;
      if (data.reviewCount) productData.reviews = data.reviewCount;
      if (data.salesRank) productData.bsr = data.salesRank;
      if (data.pageCount) productData.pages = data.pageCount;
      if (data.publicationDate) productData.publicationDate = data.publicationDate;
      if (data.publisher) {
        productData.publisher = data.publisher;
        productData.isSelfPublished = isSelfPublished(data.publisher);
      }
      if (data.format) productData.format = data.format;
      
      // Estrai dati dalle specifiche del prodotto
      if (data.productDetails || data.specifications) {
        const details = data.productDetails || data.specifications;
        
        for (const detail of details) {
          if (detail.name.toLowerCase().includes('page')) {
            productData.pages = extractNumberFromString(detail.value);
          } else if (detail.name.toLowerCase().includes('publication')) {
            productData.publicationDate = detail.value;
          } else if (detail.name.toLowerCase().includes('publisher')) {
            productData.publisher = detail.value;
            productData.isSelfPublished = isSelfPublished(detail.value);
          } else if (detail.name.toLowerCase().includes('format')) {
            productData.format = detail.value;
          }
        }
      }
    } else if (typeof data === 'string') {
      // Estrai dati dal testo HTML
      const titleMatch = data.match(/<span id="productTitle"[^>]*>([^<]+)<\/span>/i);
      if (titleMatch) productData.title = titleMatch[1].trim();
      
      const priceMatch = data.match(/id="price"[^>]*>([^<]+)<\/span>/i) || 
                        data.match(/id="priceblock_ourprice"[^>]*>([^<]+)<\/span>/i);
      if (priceMatch) productData.price = priceMatch[1].trim();
      
      const ratingMatch = data.match(/id="acrPopover"[^>]*title="([^"]+)"/i);
      if (ratingMatch) {
        const ratingText = ratingMatch[1];
        const ratingValue = ratingText.match(/(\d+(?:\.\d+)?)/);
        if (ratingValue) productData.rating = parseFloat(ratingValue[1]);
      }
      
      const reviewMatch = data.match(/id="acrCustomerReviewText"[^>]*>([^<]+)<\/span>/i);
      if (reviewMatch) {
        const reviewText = reviewMatch[1];
        const reviewCount = reviewText.match(/(\d+(?:,\d+)*)/);
        if (reviewCount) productData.reviews = parseInt(reviewCount[1].replace(/,/g, ''), 10);
      }
      
      const bsrMatch = data.match(/Best Sellers Rank(?:[^#]*)#([0-9,]+)/i) ||
                      data.match(/Classifica Bestseller(?:[^#]*)#([0-9.]+)/i);
      if (bsrMatch) productData.bsr = parseInt(bsrMatch[1].replace(/[,\.]/g, ''), 10);
      
      const pageMatch = data.match(/(\d+)\s*pages/i) || data.match(/(\d+)\s*pagine/i);
      if (pageMatch) productData.pages = parseInt(pageMatch[1], 10);
      
      const dateMatch = data.match(/Publication\s*(?:date|:)\s*(?::|;)?\s*([A-Za-z]+\s+\d{1,2},?\s+\d{4})/i) ||
                       data.match(/Data\s*(?:di)?\s*(?:pubblicazione|:)\s*(?::|;)?\s*(\d{1,2}\s+[A-Za-z]+\s+\d{4})/i);
      if (dateMatch) productData.publicationDate = dateMatch[1];
      
      const publisherMatch = data.match(/Publisher\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i) ||
                            data.match(/Editore\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i);
      if (publisherMatch) {
        productData.publisher = publisherMatch[1].trim();
        productData.isSelfPublished = isSelfPublished(productData.publisher);
      }
      
      const formatMatch = data.match(/Format\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i) ||
                         data.match(/Formato\s*(?::|;)?\s*([^;:]+?)(?:;|:|\(|$)/i);
      if (formatMatch) productData.format = formatMatch[1].trim();
    }
    
    // Salva i dati
    saveInterceptedData(asin, 'productPage', productData);
    
    // Notifica il content script
    notifyContentScript('productPageUpdated', productData);
  } catch (error) {
    console.error('Errore nell\'elaborazione dei dati dell\'API della pagina prodotto:', error);
  }
}

// Estrai l'ASIN dai dati
function extractAsinFromData(data) {
  if (typeof data === 'object') {
    if (data.asin) return data.asin;
    if (data.ASIN) return data.ASIN;
    
    // Cerca l'ASIN in proprietà annidate
    for (const key in data) {
      if (typeof data[key] === 'object' && data[key] !== null) {
        const nestedAsin = extractAsinFromData(data[key]);
        if (nestedAsin) return nestedAsin;
      }
    }
  } else if (typeof data === 'string') {
    // Cerca l'ASIN nel testo
    const asinMatch = data.match(/(?:"ASIN"|"asin")(?:\s*):(?:\s*)"([A-Z0-9]{10})"/i) ||
                     data.match(/data-asin="([A-Z0-9]{10})"/i);
    
    if (asinMatch) return asinMatch[1];
  }
  
  return null;
}

// Estrai il BSR dai dati di sales rankings
function extractBsrFromSalesRankings(salesRankings) {
  if (!salesRankings || !Array.isArray(salesRankings)) return null;
  
  // Cerca la categoria principale (solitamente Books)
  const booksRanking = salesRankings.find(ranking => 
    ranking.categoryName && (
      ranking.categoryName.toLowerCase().includes('book') || 
      ranking.categoryName.toLowerCase().includes('libri')
    )
  );
  
  if (booksRanking && booksRanking.rank) {
    return booksRanking.rank;
  }
  
  // Se non troviamo una categoria specifica, prendi il primo ranking
  if (salesRankings.length > 0 && salesRankings[0].rank) {
    return salesRankings[0].rank;
  }
  
  return null;
}

// Trova un dettaglio per nome
function findDetailByName(details, nameKeywords) {
  if (!details || !Array.isArray(details)) return null;
  
  return details.find(detail => 
    detail.name && nameKeywords.some(keyword => 
      detail.name.toLowerCase().includes(keyword.toLowerCase())
    )
  );
}

// Estrai un numero da una stringa
function extractNumberFromString(str) {
  if (!str) return null;
  
  const match = str.match(/(\d+(?:,\d+)*)/);
  if (match) {
    return parseInt(match[1].replace(/,/g, ''), 10);
  }
  
  return null;
}

// Verifica se un editore è self-published
function isSelfPublished(publisher) {
  if (!publisher) return false;
  
  const selfPubIndicators = [
    /independently published/i,
    /self published/i,
    /createspace/i,
    /kdp/i,
    /kindle direct publishing/i,
    /author house/i,
    /lulu/i,
    /book baby/i,
    /ingramspark/i
  ];
  
  return selfPubIndicators.some(regex => regex.test(publisher));
}

// Estrai elementi prodotto dall'HTML
function extractProductElementsFromHtml(html) {
  const products = [];
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  
  // Cerca gli elementi prodotto
  const productElements = doc.querySelectorAll('div.s-result-item[data-asin]');
  
  for (const element of productElements) {
    const asin = element.getAttribute('data-asin');
    if (!asin) continue;
    
    const product = {
      asin,
      isSponsored: !!element.innerText.match(/Sponsored/i)
    };
    
    // Estrai titolo
    const titleElement = element.querySelector('h2 span');
    if (titleElement) product.title = titleElement.innerText.trim();
    
    // Estrai prezzo
    const priceElement = element.querySelector("span.a-price.a-text-price span:nth-child(2)") ||
                         element.querySelector('.a-price .a-offscreen');
    if (priceElement) product.price = priceElement.innerText.trim();
    
    // Estrai rating
    const ratingElement = element.querySelector('.a-icon-star-small span');
    if (ratingElement) {
      const ratingText = ratingElement.innerText.trim();
      const ratingValue = ratingText.split(' ')[0];
      product.rating = ratingValue;
    }
    
    // Estrai recensioni
    const reviewsElement = element.querySelector('span.a-size-base.s-underline-text');
    if (reviewsElement) product.reviews = reviewsElement.innerText.trim();
    
    // Estrai BSR se disponibile
    const bsrElement = element.querySelector('span.extension-rank');
    if (bsrElement) product.bsr = bsrElement.innerText.trim();
    
    products.push(product);
  }
  
  return products;
}

// Salva i dati intercettati
function saveInterceptedData(asin, dataType, data) {
  chrome.storage.local.get('kindaCache', (result) => {
    const cache = result.kindaCache || {};
    
    if (!cache[asin]) {
      cache[asin] = {};
    }
    
    cache[asin][dataType] = {
      ...data,
      timestamp: Date.now()
    };
    
    chrome.storage.local.set({ kindaCache: cache });
  });
}

// Notifica il content script
function notifyContentScript(messageType, data) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: messageType,
        data: data
      });
    }
  });
}

// Esporta le funzioni
export {
  initApiInterceptor,
  processProductDetailsApi,
  processTechnicalSpecsApi,
  processBestSellerApi,
  processSearchApi,
  processProductPageApi
};
