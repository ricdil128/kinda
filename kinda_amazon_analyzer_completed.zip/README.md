# Guida all'Installazione e Utilizzo di Kinda Amazon Analyzer Pro

## Installazione dell'Estensione

### Metodo 1: Installazione in Modalità Sviluppatore (Consigliato)

1. **Estrai il file ZIP** in una cartella sul tuo computer
2. **Apri Chrome** e vai a `chrome://extensions/`
3. **Attiva la "Modalità sviluppatore"** usando l'interruttore nell'angolo in alto a destra
4. **Clicca su "Carica estensione non pacchettizzata"**
5. **Seleziona la cartella** dove hai estratto i file dell'estensione
6. **Verifica** che l'estensione Kinda Amazon Analyzer Pro appaia nell'elenco delle estensioni attive

### Metodo 2: Installazione Temporanea (Per Test)

1. **Estrai il file ZIP** in una cartella sul tuo computer
2. **Apri Chrome** e vai a `chrome://extensions/`
3. **Trascina il file manifest.json** dalla cartella estratta direttamente nella pagina delle estensioni di Chrome

## Utilizzo dell'Estensione

### Analisi dei Risultati di Ricerca Amazon

1. **Vai su Amazon** (amazon.com, amazon.it, ecc. in base al mercato selezionato)
2. **Cerca libri** utilizzando la barra di ricerca di Amazon
3. **Attendi** che i risultati di ricerca vengano caricati completamente
4. **Clicca sul pulsante "Estrai dati con Kinda Pro"** che appare nell'angolo in basso a sinistra della pagina
5. **Attendi** che l'analisi venga completata (una barra di progresso apparirà nell'angolo in alto a destra)
6. **Visualizza i risultati** nella tabella che apparirà nell'angolo in basso a destra

### Funzionalità Principali

#### Estrazione Dati Completi
- **Titolo, ASIN, Prezzo, Rating, Recensioni**: Estratti direttamente dalla pagina
- **BSR (Best Seller Rank)**: Ottenuto tramite intercettazione delle API interne di Amazon
- **Numero di Pagine**: Estratto dalle API o dalla pagina del prodotto
- **Data di Pubblicazione**: Estratta dalle API o dalla pagina del prodotto
- **Formato (Paperback, Kindle, etc)**: Estratto dalle API o dalla pagina del prodotto
- **Dimensione (≤6x9 o >6x9)**: Stimata dal rapporto larghezza/altezza della copertina
- **Self Published**: Rilevato automaticamente in base all'editore

#### Analisi di Profittabilità
- **Copie/Giorno**: Stima delle vendite giornaliere in base al BSR
- **Miglior ACOS**: Percentuale ottimale di spesa pubblicitaria
- **ACOS Break-Even**: Percentuale massima di spesa pubblicitaria per non andare in perdita
- **Spesa Ads**: Stima della spesa pubblicitaria giornaliera ottimale
- **Lordo/Giorno e Lordo/Mese**: Stima degli incassi lordi
- **Netto**: Stima del profitto netto mensile
- **Peso Ads**: Percentuale della spesa pubblicitaria rispetto al fatturato
- **CPC**: Costo per click stimato

#### Integrazione con Google Trends (Se abilitata)
- **Trend a Breve Termine**: Analisi degli ultimi 7 giorni
- **Trend a Medio Termine**: Analisi degli ultimi 3 mesi
- **Trend a Lungo Termine**: Analisi degli ultimi 12 mesi

### Personalizzazione delle Impostazioni

1. **Clicca sull'icona dell'estensione** nella barra degli strumenti di Chrome
2. **Seleziona il mercato Amazon** desiderato (US, UK, IT, DE, FR, ES)
3. **Imposta la durata della cache** (in ore)
4. **Attiva/disattiva le funzionalità**:
   - Analisi di Profittabilità
   - Integrazione Google Trends
   - Visualizzazione Prodotti Sponsorizzati
5. **Clicca su "Salva Impostazioni"**

### Esportazione dei Dati

1. **Analizza i risultati di ricerca** come descritto sopra
2. **Clicca sul pulsante "Esporta CSV"** nella tabella dei risultati
3. **Salva il file CSV** sul tuo computer
4. **Apri il file** con Excel, Google Sheets o qualsiasi altro software di fogli di calcolo

## Risoluzione dei Problemi

### L'estensione non mostra il pulsante di analisi
- Verifica che l'estensione sia attiva nella pagina delle estensioni di Chrome
- Assicurati di essere su una pagina di risultati di ricerca di Amazon (URL che inizia con amazon.com/s o simili)
- Ricarica la pagina e attendi il caricamento completo

### Dati mancanti o incompleti
- Clicca su "Pulisci Cache" nelle impostazioni dell'estensione
- Riprova l'analisi
- Verifica che il mercato selezionato corrisponda al sito Amazon che stai visitando

### Errori di analisi
- Verifica la connessione internet
- Assicurati che Amazon non abbia modificato la struttura della pagina (in tal caso potrebbe essere necessario un aggiornamento dell'estensione)
- Prova a ridurre il numero di risultati analizzati (filtrando i risultati di Amazon)

## Note Tecniche

### Metodo di Estrazione Dati
L'estensione utilizza un approccio ibrido per ottenere i dati:
1. **Intercettazione delle API interne di Amazon** per i dati non visibili nella SERP
2. **Estrazione dal DOM** per i dati visibili direttamente nella pagina
3. **Cache locale** per migliorare le prestazioni e ridurre le richieste

### Calcoli di Profittabilità
I calcoli di profittabilità si basano su formule e parametri standard del settore del self-publishing, ma sono da considerarsi stime indicative. I risultati reali possono variare in base a numerosi fattori.

### Privacy e Sicurezza
- L'estensione opera completamente in locale sul tuo browser
- Nessun dato viene inviato a server esterni (eccetto per l'integrazione con Google Trends, se abilitata)
- Non sono richiesti account o autenticazioni

## Aggiornamenti Futuri

Stiamo lavorando per aggiungere le seguenti funzionalità nelle prossime versioni:
- Supporto per più categorie di prodotti oltre ai libri
- Analisi avanzata della concorrenza
- Dashboard per il monitoraggio nel tempo
- Integrazione con altri strumenti di marketing

Per suggerimenti o segnalazioni di bug, contatta il team di sviluppo.

---

© 2025 Kinda Amazon Analyzer Pro - v2.0.0
