// Questo file crea icone semplici per l'estensione Kinda
// Utilizziamo Canvas per generare le icone

// Crea un canvas
const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');

// Funzione per creare un'icona
function createIcon(size) {
  // Imposta la dimensione del canvas
  canvas.width = size;
  canvas.height = size;
  
  // Pulisci il canvas
  ctx.clearRect(0, 0, size, size);
  
  // Sfondo
  ctx.fillStyle = '#111111';
  ctx.fillRect(0, 0, size, size);
  
  // Bordo arrotondato
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = Math.max(1, size / 16);
  ctx.beginPath();
  ctx.roundRect(ctx.lineWidth, ctx.lineWidth, size - ctx.lineWidth * 2, size - ctx.lineWidth * 2, size / 8);
  ctx.stroke();
  
  // Lettera K
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold ${size * 0.6}px Arial`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('K', size / 2, size / 2);
  
  // Converti in base64
  return canvas.toDataURL('image/png');
}

// Crea icone di diverse dimensioni
const icon16 = createIcon(16);
const icon48 = createIcon(48);
const icon128 = createIcon(128);

// Scarica le icone
function downloadIcon(dataURL, filename) {
  const link = document.createElement('a');
  link.href = dataURL;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

downloadIcon(icon16, 'icon16.png');
downloadIcon(icon48, 'icon48.png');
downloadIcon(icon128, 'icon128.png');
