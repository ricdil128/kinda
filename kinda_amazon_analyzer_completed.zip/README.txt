# Kinda Amazon Analyzer

**Kinda** è un'estensione Chrome progettata per analizzare rapidamente i risultati di ricerca di libri su Amazon.com e fornire una panoramica dettagliata dei principali dati utili per self-publisher, ricercatori di nicchia e autori indipendenti.

---

## 🧠 Obiettivo

Visualizzare direttamente nella pagina dei risultati di Amazon:

- **BSR (Best Seller Rank)**
- **Prezzo intero (non scontato)**
- **Numero di pagine**
- **Data di pubblicazione**
- **Formato libro (Kindle, paperback, hardcover)**
- **Self-published o no**
- **Royalty stimate (calcolate sul prezzo e sul formato)**

Tutti i dati vengono raccolti automaticamente e mostrati in una **tabella overlay** direttamente sopra i risultati di ricerca Amazon.

---

## ⚙️ Funzionalità principali

- ✅ Estrazione dati automatici dalla SERP Amazon.com
- ✅ Accesso a tooltip estesi (es. DS Amazon Quick View) per dati extra
- ✅ Fetch alla pagina prodotto se necessario (fallback strategy)
- ✅ Overlay tabellare con colonne personalizzate
- ✅ Calcolo automatico delle royalty KDP
- ✅ Export CSV dei risultati
- ✅ Auto-refresh ogni 5 secondi finché i dati non sono completi
- ✅ Cache locale per evitare richieste duplicate

---

## 🧩 Struttura del progetto

- `manifest.json` — Definizione dell'estensione (v3)
- `content.js` — Script principale che interagisce con la SERP e crea l'interfaccia
- `background.js` *(opzionale)* — Per fetch esterni e messaggi asincroni
- `style.css` — Stile personalizzato per l’overlay tabellare
- `popup.html` / `popup.js` *(se previsto)* — Finestra popup con opzioni o stato estensione
- `utils.js` — Funzioni di supporto (es. parsing prezzo, calcolo royalty, ecc.)

---

## 🔍 Come funziona

1. L'estensione si attiva su Amazon.com in pagine di ricerca libri.
2. Raccoglie ID dei prodotti visibili.
3. Tenta di leggere BSR, prezzo e altri dati direttamente dal DOM.
4. Se non trova tutto, attiva un `mouseover` sulla copertina per usare il tooltip DS Amazon Quick View.
5. Se ancora non trova i dati, fa `fetch()` alla pagina prodotto per estrarre info aggiuntive.
6. Mostra tutto in una **tabella overlay** con possibilità di esportazione.

---

## 🚀 Obiettivi futuri

- [ ] Miglioramento stabilità tooltip DS Quick View
- [ ] Versione Firefox
- [ ] Aggiunta filtro per SP/non-SP
- [ ] Ordinamento per colonna nella tabella
- [ ] Dashboard cloud collegata

---

## 🤖 Come usarlo

1. Clona o scarica il progetto.
2. Vai su `chrome://extensions/` e abilita **"Developer Mode"**.
3. Clicca su **"Load Unpacked"** e seleziona la cartella di Kinda.
4. Vai su Amazon.com e fai una ricerca libri.
5. L'estensione attiverà l'overlay automaticamente.

---

## 🧠 Prompt per AI / Manus

> "Completa questo progetto Chrome Extension: deve analizzare i risultati di Amazon.com, estrarre dati da tooltip DS Amazon Quick View o via fetch alla pagina libro, mostrarli in una tabella overlay, calcolare royalty, permettere export CSV e aggiornarsi ogni 5 secondi fino al completamento dei dati. Ecco i file iniziali."

---

## 👤 Autore

**Riccardo** – Self-publisher, sviluppatore di strumenti intelligenti per il mondo editoriale.

---

## 📄 Licenza

MIT – Usalo, miglioralo, condividilo.
