// popup.js - Gestisce l'interfaccia utente del popup dell'estensione

// Inizializzazione
document.addEventListener('DOMContentLoaded', () => {
  // Carica le impostazioni correnti
  loadSettings();
  
  // Configura gli event listener
  setupEventListeners();
});

chrome.runtime.sendMessage({ type: 'ping' }, (res) => {
  console.log('[POPUP] Risposta dal service worker:', res);
});

// Verifica se siamo su una pagina Amazon
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const url = tabs[0]?.url || '';
  const isAmazon = /^https?:\/\/(www\.)?amazon\./i.test(url);

  if (!isAmazon) {
    // Disabilita pulsanti
    document.getElementById('save-settings').disabled = true;
    document.getElementById('clear-cache').disabled = true;

    // Mostra messaggio
    const statusMessage = document.getElementById('status-message');
    statusMessage.textContent = '⚠️ Apri Amazon per usare l\'estensione.';
  }
});

// Carica le impostazioni
function loadSettings() {
  chrome.storage.local.get('kindaSettings', (result) => {
    const settings = result.kindaSettings || {
      market: 'US',
      cacheExpiration: 24,
      enableProfitabilityAnalysis: true,
      enableGoogleTrends: false,
      showSponsoredItems: true
    };
    
    // Imposta i valori nei campi del form
    document.getElementById('market-select').value = settings.market || 'US';
    document.getElementById('cache-expiration').value = (settings.cacheExpiration || 86400000) / 3600000; // Converti da ms a ore
    document.getElementById('enable-profitability').checked = settings.enableProfitabilityAnalysis !== false;
    document.getElementById('enable-google-trends').checked = settings.enableGoogleTrends === true;
    document.getElementById('show-sponsored').checked = settings.showSponsoredItems !== false;
  });
}

// Configura gli event listener
function setupEventListeners() {
  // Salva le impostazioni
  document.getElementById('save-settings').addEventListener('click', saveSettings);
  
  // Pulisci la cache
  document.getElementById('clear-cache').addEventListener('click', clearCache);
}

// Salva le impostazioni
function saveSettings() {
  const settings = {
    market: document.getElementById('market-select').value,
    cacheExpiration: document.getElementById('cache-expiration').value * 3600000, // Converti da ore a ms
    enableProfitabilityAnalysis: document.getElementById('enable-profitability').checked,
    enableGoogleTrends: document.getElementById('enable-google-trends').checked,
    showSponsoredItems: document.getElementById('show-sponsored').checked
  };
  
  chrome.storage.local.set({ kindaSettings: settings }, () => {
    // Aggiorna il messaggio di stato
    const statusMessage = document.getElementById('status-message');
    statusMessage.textContent = 'Impostazioni salvate con successo!';
    
    // Ripristina il messaggio dopo 2 secondi
    setTimeout(() => {
      statusMessage.textContent = 'Estensione pronta. Vai su Amazon e cerca libri per iniziare.';
    }, 2000);
    
    // Notifica il content script
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0 && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'settingsUpdated',
          settings: settings
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.warn('Content script non disponibile sulla scheda corrente.');
            // Puoi anche aggiornare lo stato visivo se vuoi
            const statusMessage = document.getElementById('status-message');
            statusMessage.textContent = '⚠️ Content script non attivo su questa pagina.';
            return;
          }
          console.log('Risposta dal content script:', response);
          });
      }
    });
  }); // Chiude chrome.storage.local.set
} // ✅ Chiude saveSettings

// Pulisci la cache
function clearCache() {
  // Pulisci la cache dell'estensione
  chrome.runtime.sendMessage({ type: 'clearCache' }, (response) => {
    const statusMessage = document.getElementById('status-message');

    if (response && response.success) {
      statusMessage.textContent = 'Cache pulita con successo!';
      
      setTimeout(() => {
        statusMessage.textContent = 'Estensione pronta. Vai su Amazon e cerca libri per iniziare.';
      }, 2000);
    } else {
      statusMessage.textContent = 'Errore durante la pulizia della cache.';
    }
  });
}
