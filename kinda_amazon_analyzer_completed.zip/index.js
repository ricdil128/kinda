// index.js - File principale che importa e inizializza tutti i moduli dell'estensione

// Importa i moduli
import { initApiInterceptor } from './api-interceptor.js';
import ProfitabilityAnalyzer from './profitability-analyzer.js';
import GoogleTrendsAnalyzer from './google-trends-analyzer.js';

// Inizializza l'interceptor delle API
initApiInterceptor();

// Crea le istanze degli analizzatori
const profitabilityAnalyzer = new ProfitabilityAnalyzer();
const trendsAnalyzer = new GoogleTrendsAnalyzer();

// Esporta le istanze per l'uso in altri moduli
export {
  profitabilityAnalyzer,
  trendsAnalyzer
};
